/******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY,
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and
*   conditions found by accessing the following link:
*   http://www.renesas.com/disclaimer
********************************************************************************
*   Copyright (C) 2013 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7269 SDIO HOST Sample Program
*   File Name   : main.c
*   Abstract    : Sample Program Main
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.08.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.04 Release00).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description :
********************************************************************************
*   History     : May.22,2013 Ver.1.00.00
*               :
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <machine.h>
#include "iodefine.h"
#include "r0k57269.h"
#include "sdio_if.h"


#include "command.h"


/* ==== Global variable ==== */
#pragma section BUFF
unsigned long buff[512*10];
char buff1[512];

#pragma section

static char g_command_buff[2048];			/* �ėp�̃o�b�t�@     */
char g_command_arg[ARGC][MAX_ARGLENGTH];	/* ���̓R�}���h�i�[�p */
int fs_command_mode = MODE_SDIO;
int rdFlag=0;
int sdio_cmd53_byt_w(char* DataBuff, int len);
int
GsSdio_RxDataLength();
int GsSdio_DataSend(char *cmdBuff, int length);
int
GsSdio_Enable();
int
GsSdio_IntEnable();
int
GsSdio_IntClear();
int
GsSdio_BlockSizeSet(int block_size);

int throughputTest=0;
int pktSize =0;
int pktNo=0;
unsigned long long MpktSize=0;
unsigned long long MpktNo =0;

ST_COMMAND sdio_cmd[] = {
	{"MOUNT",			cmd_sdio_mount,			help_sdio_mount},
	{"UNMOUNT",			cmd_sdio_unmount,		help_sdio_unmount},
	{"GET_INFO",		cmd_sdio_get_info,		help_sdio_get_info},
	{"CMD52_R",			cmd_sdio_cmd52_r,		help_sdio_cmd52_r},
	{"CMD52_W",			cmd_sdio_cmd52_w,		help_sdio_cmd52_w},
	{"CMD53_BYT_R",		cmd_sdio_cmd53_byt_r,	help_sdio_cmd53_byt_r},
	{"CMD53_BYT_W",		cmd_sdio_cmd53_byt_w,	help_sdio_cmd53_byt_w},
	{"CMD53_BLK_R",		cmd_sdio_cmd53_blk_r,	help_sdio_cmd53_blk_r},
	{"CMD53_BLK_W",		cmd_sdio_cmd53_blk_w,	help_sdio_cmd53_blk_w},
	{"SET_BUS_WIDTH",	cmd_sdio_set_bus_width,	help_sdio_set_bus_width},
	{"SET_BLOCK_SIZE",	cmd_sdio_set_block_size,help_sdio_set_block_size},
	{"EXIT",	cmd_sdio_exit,help_sdio_exit},
	{"TXTEST",	cmd_sdio_txtest,help_sdio_txtest},
	{"RXTEST",	cmd_sdio_rxtest,help_sdio_rxtest},

	{NULL, 		NULL, 			NULL}
};

/* ==== prototype declaration ==== */
void main(void);
int commad_exe(char *buff);
int commad_exe1(char *buff);
int cmdline_split(char *cmdline,char *argv[]);
static int cmdline_pars(int argc, char *argv[]);
static ST_COMMAND *get_cmd_list(void);

extern int g_io_sddev_sdio_cd;			/* card insert/remove flag in sdio_userdef.c */

static int sdio_set_blk_sz(int block_size);
static int sdio_set_func1_enable(void);
void
dataTxBlockNtimes(char* buff, int block_size,int block_num,int ntimes);
int
readResponseFromCard(char* dBuff, int length);
#define ADDR_CCCR_IOENABLE 0x02
#define ADDR_CCCR_INTENABLE 0x04
#define TRUE 1

extern int Info1[1024],Info2[1024],Index;
int timeCount=0;
unsigned long long preTime=0,preTime1=0,preTimeVal=0,postTimeVal=0;
#if 0
/*******************************************************************************
 * ID          :
 * Outline     : main
 * Include     :
 * Declaration : void main(void);
 * Description :
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void main(void)
{

	const char *cmd_msg[2] ={"SDIO",""};

	puts("\nSH7269 SDIO HOST Sample Program. Ver.1.00.00");
    puts("Copyright (C) 2013 Renesas Electronics Corporation. All rights reserved.");
	puts("\n");

	/* === SDHI Initialization === */
	io_sd_init();

	/* Wait command */
	while(1) {
		/* Input  command */
		printf("%s> ",cmd_msg[fs_command_mode]);
		fflush(stdout);
		if (gets(g_command_buff) == NULL) {
			printf("error: gets error\n");
			break;
		}

		/* Execute command */
		commad_exe(g_command_buff);
		fflush(stdout);
	}

}

#else
void main(void)
{

	unsigned int i,j,length,noCmdFlag,lenCount=0,lenValue=0,returnLen=0,ret=0;
	long tmp;
	const char *cmd_msg[2] ={"SDIO",""};
    RW_EXTENDED_ARG ext_arg;
	unsigned char *ptr;
	char localBuff[64];
	puts("\nSH7269 SDIO HOST Sample Program. Ver.1.00.00");
    puts("Copyright (C) 2013 Renesas Electronics Corporation. All rights reserved.");
	puts("\n");

	/* === SDHI Initialization === */
	io_sd_init();
    // wait for the card insertion
	puts("Waiting for SD Card Insertion...\n");
	while(!g_io_sddev_sdio_cd);
	// card is ready then start the mount
	puts("Waiting for SDIO Card Initialization...\n");
	// wait for 5 sec time for the S2W adapter initialization

	for(i=0;i<100000;i++)
	{
	   for(j=0;j<1000;j++)
	   {
	   }
	}
	if(io_sd_mount() == SD_OK){
		puts("[SD] card mount OK");
	}
	else{
		puts("[SD] card mount ERROR\n");
	}
	printf("\n");
	fflush(stdout);
	rdFlag=0;
    GsSdio_Enable();
    // Enable interrupts
    GsSdio_IntEnable();

    //printf("IO card Enabled\n");
	// set th block size to 512
	GsSdio_BlockSizeSet(512);

	//printf("IO Blk sizeenabled\n");
	noCmdFlag =0;

    while(1)
    {
	    if(g_io_sddev_sdio_cd == 0)
		{
		    io_sd_init();
			puts("Waiting for SD Card Insertion...\n");
	        while(!g_io_sddev_sdio_cd);
	        // card is ready then start the mount
	     	puts("Waiting for SDIO Card Initialization...\n");
	// wait for 5 sec time for the S2W adapter initialization

	for(i=0;i<100000;i++)
	{
	   for(j=0;j<1000;j++)
	   {
	   }
	}
	        io_sd_unmount();
	        if(io_sd_mount() == SD_OK)
			{
		       puts("[SD] card mount OK");
	        }
	        else
			{
		       puts("[SD] card mount ERROR\n");
	        }
	        printf("\n");
	        fflush(stdout);
	        rdFlag=0;
            GsSdio_Enable();
            // Enable interrupts
            GsSdio_IntEnable();

            //printf("IO card Enabled\n");
	        // set th block size to 512
	        GsSdio_BlockSizeSet(512);

	        //printf("IO Blk sizeenabled\n");
	        noCmdFlag =0;
		}
	    // check for any messages from slave
        if(rdFlag) // data present
        {
	        rdFlag= 0;
		    GsSdio_IntClear();
		    // read numbers
		    length = GsSdio_RxDataLength(); // get the length of the data to read

	        //printf("\r\nLength:%x\n",length);
		    if(length)
		    {
	            memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));
	            returnLen= GsSdio_DataRead(buff,length );
		        ptr = (unsigned char *)buff;
	            for(i=0;i<returnLen;i++)
	            {
		            //printf("%x",*ptr);
	                printf("%c",*ptr++);
	            }

		   }
		   io_sd_enable_sdio_int();
		   //readdata = 0;

        }

	    /* Wait command */
	    //while(1) {
		/* Input  command */
		if(!noCmdFlag)
		{
		    printf("%s> ",cmd_msg[fs_command_mode]);
		    fflush(stdout);
			noCmdFlag = 1;
		}

		// issue a non block read for 1 char, it recv the get for full command till \n
		g_command_buff[0] = io_getcharNonBlock();
		if(g_command_buff[0] != 0)
		{
		    unsigned char ch=0;
		    // if the char recv is esc then goes to data mode
			if(g_command_buff[0] == 0x1B) // data mode so we recve data
			{
			    int index =1;
			    ch = io_getchar();
				g_command_buff[index] = ch;
				index++;
				// if the bulk mode data received then
				if((ch == 'Z'))
				{
				    lenValue =0;
				    // get the cid
				    ch = io_getchar();
				    g_command_buff[index] = ch;
				    index++;
                    // get the length
				    for(lenCount=0;lenCount<4;lenCount++)
				    {
                        ch = io_getchar();
				        g_command_buff[index] = ch;
				        index++;
                        lenValue *= 10;
					    lenValue += (ch-'0');
					}
					printf("\n Len:Send:%d\n",lenValue);
					// get the data
					for(lenCount=0;lenCount<lenValue;lenCount++)
					{
                        ch = io_getchar();
				        g_command_buff[index] = ch;
				        index++;
                    }
                    if(throughputTest)
                    {
#if 1

                        printf("\nThrouhput test started with %lld pkts of %lld size\n",MpktNo,MpktSize);
						// get the system time from the node
                        memset(localBuff,0,64);
                        memcpy(localBuff,"AT+GETTIME=?\r",13);
                        // to process the response to be received set the flag
                        preTime=1;
                        commad_exe1(localBuff);
                        //preTime=0;
                        // check anything pending on the rx side if yes read it back
                        while(1)
                        {
                        if(rdFlag) // data present
				        {
					        rdFlag= 0;
						    GsSdio_IntClear();
						    // read numbers
						    length = GsSdio_RxDataLength(); // get the length of the data to read

					        //printf("\r\nLength:%x\n",length);
						    if(length)
						    {
					            memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));
					            returnLen= GsSdio_DataRead(buff,length );
						        ptr = (unsigned char *)buff;
					            for(i=0;i<returnLen;i++)
					            {
						            //printf("%x",*ptr);
					                //printf("%c",*ptr++);
					            }

						   }
						   io_sd_enable_sdio_int();
						   //readdata = 0;

                        }
                        else
                        {
							break;
						}
					    }
#endif
						for(i=0;i<MpktNo;i++)
						{

						    ret=GsSdio_DataSend(g_command_buff, index);
						    if(ret ==0)
						    {
								//printf("\n send error:%d\n",index);
								//break;
								//#if 0
								// wait for some time
								timeCount = 10000;
								while(1)
								{
									if(timeCount==0)
									{
									   break;
								    }
								    timeCount--;
								}
								//#endif

							}
						}
						memset(localBuff,0,64);
                        memcpy(localBuff,"AT+GETTIME=?\r",13);
                        preTime1=1;
						commad_exe1(localBuff);
						//preTime1=0;
					}

			    }
				else if((ch == 'S'))
				{
				    while(1)
					{
				        ch = io_getchar();
				        g_command_buff[index] = ch;
				        index++;
						if(ch == 0x1B)
				        {
				            g_command_buff[index] = io_getchar();
				            index++;
					        break;
				        }
					}
				}else // esc C
				{
				    commad_exe1(g_command_buff);
				}
				if(!throughputTest)
				{
				// send the data to s2w
				ret=GsSdio_DataSend(g_command_buff, index);
			   }

			}
			else
			{
		        // echo the char recvd
			    io_putchar(g_command_buff[0]);
			    if((g_command_buff[0] != '\n') && (g_command_buff[0] != '\r') )
			    {
			        if (gets(&g_command_buff[1]) == NULL)
			        {
			            printf("error: gets error\n");
			            //break;
		            }

		            /* Execute command */
		            commad_exe1(g_command_buff);
		            //fflush(stdout);
			    }
			}
			noCmdFlag = 0;
		}
	//}

	}

}

#endif

/*******************************************************************************
 * ID          :
 * Outline     : �R�}���h�̎��s
 * Include     :
 * Declaration : int commad_exe(char *buff);
 * Description : buff�Ŏw�肳�ꂽ�R�}���h�����s���܂��B
 * Argument    : char *buff : �R�}���h������
 * Return Value: ���s����
 * Note        : None
*******************************************************************************/
int commad_exe(char *buff)
{
	int i;
	int argc;
	char *argv[ARGC];

	argc = cmdline_split(buff,argv);

	for (i = 0; i < ARGC; i++){
		argv[i] = g_command_arg[i];
	}

	if (argc) {
		return cmdline_pars(argc,argv);
	}

	return 0;
}


int commad_exe1(char *cmdBuff)
{
	int status=0;
	int argc=0,argc1=0;

	argc= strlen(cmdBuff);
	cmdBuff[argc] ='\r';
	cmdBuff[argc+1] ='\n';
	//printf("\n CmdLength:%d\n",argc+2);
	rdFlag = 0;
	if(argc == 0)
	{
	    puts(cmdBuff);
	    return 0;
	}
    // check the command is local for throughput measurement
    if(memcmp(cmdBuff,"AT+THROUGHPUT=",14) == NULL)
    {
		if(cmdBuff[14] == '1' )
		{
		   throughputTest = 1;
	       // check the pkt size 4 bytes
	       pktSize = (cmdBuff[19]-'0');
	       pktSize = pktSize + ((cmdBuff[18]-'0')*10);
	       pktSize = pktSize + ((cmdBuff[17]-'0')*100);
	       pktSize = pktSize + ((cmdBuff[16]-'0')*1000);
           if(!pktSize)
	       {
			   pktSize=1024;
           }
           MpktSize = pktSize;
		   // check the no of pkts 6 bytes
           pktNo = (cmdBuff[26]-'0');
		   pktNo = pktNo + ((cmdBuff[25]-'0')*10);
	       pktNo = pktNo + ((cmdBuff[24]-'0')*100);
		   pktNo = pktNo + ((cmdBuff[23]-'0')*1000);
		   pktNo = pktNo + ((cmdBuff[22]-'0')*10000);
		   pktNo = pktNo + ((cmdBuff[21]-'0')*100000);
		   if(!pktNo)
		   {
			   pktNo=1000;
		   }
		   MpktNo =pktNo;
	   }

	   else
	   {
		   throughputTest = 0;
	   }
	   printf("\r\n Pkt Size:%lld-Pkt No:%lld\r\n",MpktSize,MpktNo);
	   return 0;



	}
	if(memcmp(cmdBuff,"AT+REGREAD=?",12) == NULL)
    {

		sd_reg_read();
		return 0;
	}

	status = sdio_cmd53_byt_w(cmdBuff, argc+2);
	if(!status)
	{
	    int length=0,i=0,len=0;
	    unsigned char reg;
	    unsigned int fn=1;		/* function0 */
	    long addr;
	    long tmp;
	    unsigned char readdata,readdata1,readdata2,readdata3;
	    RW_EXTENDED_ARG ext_arg;
	    unsigned char *ptr;
	    unsigned short	info1;
	    memset(buff1,0,512);

	   	while(1)
		{
	        while(!rdFlag);
	        {
	           // issue the read  for the recvd data
	        }
        //puts("\nrd-isr\n");
	    rdFlag = 0;
	    // read int register
	    GsSdio_IntClear();

        length=GsSdio_RxDataLength();
        //printf("\nCount:%x\n",length);
		{

    // read the data
	ext_arg.bit.rw_flag=0;			/* read */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */
	ext_arg.bit.function_number = 1;

	ext_arg.bit.count = length;

	    /* Check Register Address */
	ext_arg.bit.register_address = 0x00;

    memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));
	/* Send CMD53 (READ/BYTE) */
	if(io_sd_read_extneded(&ext_arg,buff) != SD_OK){
		   puts("CMD53 error\n");
		   break;
	    }
		}
		//status = readResponseFromCard(buff,length);
        io_sd_enable_sdio_int();
	    ptr = (unsigned char *)buff;
	    if((preTime)||(preTime1))
	    {
			memcpy(&(buff1[len]),buff,length);
			len += length;

		}
	    if((!preTime) && (!preTime1))
	    {
	        for(i=0;i<length;i++)
	        {
		        printf("%c",*ptr++);
	        }
		}
	    //rdFlag = 0;
        //io_sd_enable_sdio_int();
		if((strstr(buff, "OK") != NULL) ||(strstr(buff, "ERROR") != NULL) ||(strstr(buff, "Reply from") != NULL))
		{
		   int colon=0;
		   int comma =0;
		   unsigned long long speed=0;
		   char * endptr;
		   long val=0,localindex=0;
			// parse the time recvd for through put test
           if((preTime) || (preTime1))
           {
			   ptr=(unsigned char *)buff1;
			   while(ptr)
			   {
				   if((colon == 2)&&(comma == 2))
				   {
                       localindex++;
                       // search till the end
					   if(*ptr == '\r')
					   {
						   *ptr = '\0';
						   val = strtol((ptr-(localindex-1)),endptr,10);
						   if(preTime)
						   {
							   preTimeVal=val;
							   preTime =0;
						   }
						   else
						   {
                               postTimeVal=val;
                               preTime1 =0;
                               // calculate the throughput
                               speed = postTimeVal - preTimeVal;
                               printf("\r\nStart Time %lld,End Time %lld\r\n",preTimeVal,postTimeVal);
                               printf("\r\nTime in MSec for %lld*%lld Bytes Data Tranfer is :%lld\n",MpktSize,MpktNo,speed);

                               speed = (MpktSize*MpktNo*8)/speed;
                               printf("\r\nSpeed:%llu kbps\n",speed);

						   }
						   break;
					   }


				   }
				   if(*ptr== ':')
				   {
					   colon++;

				   }
				   if(*ptr== ',')
				   {
					   comma++;
				   }
				   ptr++;
			   }
		   }

		   //printf("\nbreak\n");
		   break;
		}
		}
		//fflush(stdout);

	}

}



int GsSdio_DataSend(char *dataBuff, int length)
{
	static int loopCount=0;
    unsigned int fn, cnt=0, cntmode=0;
    unsigned char readdata=0,readdata1=0;
	RW_EXTENDED_ARG ext_arg;
    memset(&ext_arg,0,sizeof(RW_EXTENDED_ARG));
	ext_arg.bit.rw_flag=1;			/* write */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */


	ext_arg.bit.function_number = 1;

	ext_arg.bit.count = length;

	ext_arg.bit.register_address = 0x00;
	loopCount++;
	if(length > 512)
	{
	    cnt = length/512;
		cntmode = length%512;
		ext_arg.bit.block_mode = 1;
		ext_arg.bit.count = cnt;
	}
    //printf("\r\nBl:%d-Byt:%d-%d\r\n",ext_arg.bit.count,cntmode,loopCount);

	if(io_sd_write_extneded(&ext_arg, dataBuff) != SD_OK){

		//puts("CMD53(Byte Write) error\n");
		//printf("Bl:%d-Byt:%d-%d\r\n",ext_arg.bit.count,cntmode,loopCount);
		//return 0;
	}

    if(cntmode)
	{
	    ext_arg.bit.block_mode = 0;
		ext_arg.bit.count = cntmode;
	    if(io_sd_write_extneded(&ext_arg, &dataBuff[cnt*512]) != SD_OK){
		   //puts("CMD53(Byte Write) error\n");
		   return (cnt*512);
	   }
	}
	return length; /* Normal End */
}




#if 0





	int status=0;
	printf("\n Length:%d\n",length);
	rdFlag = 0;

	status = sdio_cmd53_byt_w(cmdBuff, length);
	if(!status)
	{
	    int length=0,i=0;
	    unsigned char reg;
	    unsigned int fn=1;		/* function0 */
	    long addr;
	    long tmp;
	    unsigned char readdata,readdata1,readdata2,readdata3;
	    RW_EXTENDED_ARG ext_arg;
	    unsigned char *ptr;
	    unsigned short	info1;
	   	while(1)
		{
		   //puts("\nrd-\n");
	        while(!rdFlag);
	        {
	           // issue the read  for the recvd data
	        }
            //puts("\nrd-isr\n");
	        rdFlag = 0;
	        // read int register

	        addr = 0x04;
	        if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
		    puts("CMD52_R ERROR\n");
		    }
	        io_sd_clear_sdio_int();

            length=GsSdio_RxDataLength();
            printf("\nCount:%x\n",length);
		    {

                // read the data
	            ext_arg.bit.rw_flag=0;			/* read */
				ext_arg.bit.block_mode=0;		/* bytes access */
				ext_arg.bit.op_code=1;			/* incrementing address */
				ext_arg.bit.function_number = 1;

				ext_arg.bit.count = length;

					/* Check Register Address */
				ext_arg.bit.register_address = 0x00;

				memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));
				/* Send CMD53 (READ/BYTE) */
				if(io_sd_read_extneded(&ext_arg,buff) != SD_OK){
					   puts("CMD53 error\n");
					   //return -1;
				}
		    }
			//status = readResponseFromCard(buff,length);

			ptr = (unsigned char *)buff;
			for(i=0;i<length;i++)
			{
			   printf("%c",*ptr++);
			}
			//rdFlag = 0;
			io_sd_enable_sdio_int();
			if((strstr(buff, "O") != NULL) ||(strstr(buff, "F") != NULL))
			{
			   //printf("\nbreak\n");
			   break;
			}
		}
		//fflush(stdout);

	}

}

#endif
/*******************************************************************************
 * ID          :
 * Outline     : �R�}���h���C�������̕���
 * Include     :
 * Declaration : int cmdline_split(char *cmdline,char *argv[])
 * Description : �R�}���h���C�������̕���
 *             : cmdline������̓��e���X�y�[�X�P�ʂŒP��ɕ�����
 *             : �o������argv�Ɋi�[���܂��B
 * Argument    : char *cmdline; �R�}���h���C��������
 *             : char *argv[]; ���������P��̊i�[��
 * Return Value: ���������P��̐���Ԃ�
 * Note        : None
*******************************************************************************/
int cmdline_split(char *cmdline,char *argv[])
{
	int i,argc;
	char *s;
	char *ptr;


	for (i = 0; i < ARGC; i++){
		g_command_arg[i][0] = '\0';
	}

	s = cmdline;
	if (*s == '>'){
		s++;
	}


	/* �R�}���h���C����� */
	for (argc = 0; argc < ARGC; ) {
		ptr = g_command_arg[argc];
		/* ������O�̃z���C�g�X�y�[�X�폜 */
		while((*s != '\0') && isspace((unsigned char)*s)){
			s++;
		}

		i=0;

		/* �_�u���R�[�e�[�V�����̏ꍇ */
		if(*s == '\"'){
			s++;
			while((*s != '\"') && (*s != '\0')){
				*ptr++=*s++;
				i++;
				if(i >= MAX_ARGLENGTH){
					puts("command line is too long\n");
					return 0;
				}
			}
			s++;
		}

		/* �������̃z���C�g�X�y�[�X���� */
		while ((*s != '\0') && (!isspace((unsigned char)*s))) {
			*ptr++=*s++;
			i++;
			if(i >= MAX_ARGLENGTH){
				puts("command line is too long\n");
				return 0;
			}
		}
		*ptr = '\0';
		argc++;
		if (*s == '\0' || *s == '\n'){
			if(i==0){
				argc--;
			}
			break;
		}
	}

	return argc;
}

/*******************************************************************************
 * ID          :
 * Outline     : �R�}���h���C�������̉��
 * Include     :
 * Declaration : int cmdline_pars(int argc, char *argv[]);
 *             :
 * Description : �R�}���h���C�������̉��
 *             : �P�ꐔargc�A�P��argv�Ŏw�肳�ꂽ�R�}���h����͂�
 *             : �Ή������R�}���h���������s���܂��B
 *             : ���s����R�}���h�́A�R�}���h�e�[�u��
 *             : char *cmd_str[] ;
 *             : �œo�^�����R�}���h�ł��B
 *             : �R�}���h��ǉ�/�폜����ꍇ�́A�R�}���h�e�[�u��cmd_str[]��
 *             : �R�}���h�e�[�u���ɑΉ������֐��e�[�u��
 *             :  int (*cmdexe[])(int, char **) ;
 *             : ���C�����Ă��������B
 *             :
 * Argument    : int  argc ;
 *             : char *argv[];
 *             :
 * Return Value:  >0 ; �R�}���h�����Ɉˑ�
 *             : 0  ; ����I��
 *             : -1 ; EXIT�R�}���h���o
 * Note        : None
*******************************************************************************/
static int cmdline_pars(int argc, char *argv[])
{
	int ret=0,i;
	char *s;
	ST_COMMAND *pcmd;

	/* �R�}���h������啶���ϊ� */
	for (s = argv[0]; *s != '\0'; s++){
		*s = toupper((unsigned char)*s);
	}

	/* �I�v�V����������啶���ϊ� */
	for (i = 1; i < argc; i++) {
		if ((argv[i][0] == '/') || (argv[i][0] == '+') || (argv[i][0] == '-')) {
			for (s = argv[i]; *s != '\0'; s++){
				*s = toupper((unsigned char )*s);
			}
		}
	}

	pcmd = get_cmd_list();

	/* �v���R�}���h����͎��s */
	while(pcmd->cmd_str != NULL){
		if (!strcmp(pcmd->cmd_str, g_command_arg[0])) {
			return (*pcmd->cmdexe)(argc, argv);
		}
		pcmd++;
	}

	printf("error: %s is unsupport command\n", g_command_arg[0]);

	return ret;
}

/*******************************************************************************
 * ID          :
 * Outline     : �R�}���h�e�[�u���̐擪�A�h���X�擾
 * Include     :
 * Declaration : static ST_COMMAND *get_cmd_list(void);
 *             :
 * Description : SDIO���[�h�FSDIO�p�R�}���h��񂪊i�[����Ă���
 *             :             sdio_cmd�̐擪�A�h���X��Ԃ�
 * Argument    : none
 * Return Value: �R�}���h�e�[�u���̐擪�A�h���X
 * Note        : None
*******************************************************************************/
static ST_COMMAND *get_cmd_list(void)
{
	ST_COMMAND *pcmd;

	if(fs_command_mode == MODE_SDIO){
		pcmd = sdio_cmd;
	}
	else{
		pcmd = sdio_cmd;
	}

	return pcmd;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_DIRECT�R�}���h�̎��s(Read)
 * Include     :
 * Declaration : int cmd_sdio_cmd52_r(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error End
 * Note        : 1
*******************************************************************************/
int cmd_sdio_cmd52_r(int argc, char **argv)
{
	unsigned char regbyte;
	unsigned int fn;
	long addr;
	int i,j;
	long byte;
	int raw=0;	/* read after write */
	int cnt=0;	/* �ǂݏo���� */
	int roop_num;
	long base_addr;
	int offset;

	if (argc != 4) {
		goto sdio_cmd52_r_usage;
	}

	/* Check Function Number */
	fn = atoi(argv[1]);
	if(fn > 7){
		goto sdio_cmd52_r_usage;
	}

	/* Check ByteNum */
	byte = atoi(argv[3]);
	if( (byte == 0) || (byte > 512) ){
		goto sdio_cmd52_r_usage;
	}

	/* Check Register Address */
	addr = atoi(argv[2]);
	if( addr > 0x1FFFF ){
		goto sdio_cmd52_r_usage;
	}

	/* �͈͓�? */
	if( (addr + byte) > 0x200000 ){
		goto sdio_cmd52_range_err;
	}
	roop_num = (byte + 16 + (addr & 0xF) -1)/16;
	offset = (addr & 0xF);
	base_addr = addr & 0x1FFF0;
	cnt = 0;

	for(j=0; j < roop_num; j++){
		printf("%06X : ", j*16 + base_addr);
		for(i=0; i < 16; i++){
			if( (j == 0) && (i < offset) ){
				printf("-- "); /* �ŏ��̒[�� */
			}
			else if( cnt >= byte ){ /* �w��o�C�g���ȏ�ǂݏo������"-- " */
				printf("-- ");
			}
			else{
				if(io_sd_read_direct(fn, base_addr+i+j*16,raw,&regbyte) == SD_OK){
					printf("%02x ",regbyte);
				}
				else{
					printf("read error\n");
					break;
				}
				cnt++;
			}
		}
		printf("\n");
	}

	printf("\n\n");
	fflush(stdout);
	return 0; /* normal end */


sdio_cmd52_r_usage:
	printf("usage: %s FunctionNumber(0~7) StartAddress(0~0x1FFFF) ByteNum(1~512)<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;

sdio_cmd52_range_err:
	printf("Address Range Error\n");
	fflush(stdout);
	return -1;

}

/*******************************************************************************
 * ID          :
 * Outline     : help of CMD52_R
 * Include     :
 * Declaration : int help_sdio_cmd52_r(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_cmd52_r(void)
{
	printf("usage: CMD52_R FunctionNumber(0~7) StartAddress(0~0x1FFFF) ByteNum(1~512)<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_DIRECT�R�}���h�̎��s(Write)
 * Include     :
 * Declaration : int cmd_sdio_cmd52_w(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : 1�o�C�g���̃��C�g
 *             : ���W�X�^�̎d�l�ɂ��A���C�g�����f�[�^�����W�X�^��
 *             : ���f����Ȃ��ꍇ������܂��B
*******************************************************************************/
int cmd_sdio_cmd52_w(int argc, char **argv)
{

	unsigned int fn;
	long addr;
	long tmp;
	unsigned char writedata,readdata;
	int raw;

	if (argc != 5) {
		goto sdio_cmd52_w_usage;
	}

	/* Check Function Number */
	fn = atoi(argv[1]);
	if(fn > 7){
		goto sdio_cmd52_w_usage;
	}

	/* Check Register Address */
	addr = atoi(argv[2]);
	if( addr > 0x1FFFF ){
		goto sdio_cmd52_w_usage;
	}

	/* Check RawFlag */
	raw = atoi(argv[3]);
	if( (raw != 0) && (raw != 1) ){
		goto sdio_cmd52_w_usage;
	}

	/* Check Write Data */
	tmp =  atoi(argv[4]);
	writedata = (unsigned char)tmp;
	if( (writedata < 0) || (writedata > 0xFF) ){
		goto sdio_cmd52_w_usage;
	}

	/* Send CMD52 (WRITE) */
	if(io_sd_write_direct((unsigned int)fn, (unsigned int)addr,(unsigned int)raw,&writedata) == SD_ERR){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	/* Send CMD52 (READ) */
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
		puts("CMD52_R ERROR\n");
		return -1;
	}

	printf("writedata = %02x \n",writedata);
	printf("readdata = %02x \n",readdata);

	printf("\n\n");
	fflush(stdout);
	return 0; /* normal end */


sdio_cmd52_w_usage:
	printf("usage: %s FunctionNumber(0~7) RegisterAddress(0~0x1FFFF) RawFlag(0or1) WriteData(0x00~0xFF)<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;

}

/*******************************************************************************
 * ID          :
 * Outline     : help of CMD52_W
 * Include     :
 * Declaration : int help_sdio_cmd52_w(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_cmd52_w(void)
{
	printf("usage:CMD52_W FunctionNumber(0~7) RegisterAddress(0~0x1FFFF) RawFlag(0or1) WriteData(0x00~0xFF)<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_DIRECT�R�}���h�̎��s(Read)
 * Include     :
 * Declaration : int cmd_sdio_get_info(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        :
*******************************************************************************/
int cmd_sdio_get_info(int argc, char **argv)
{
	unsigned char regbyte;
	unsigned int fn =0;		/* function0 */
	int raw = 0;			/* read after write */
	int sdio_fn_num;

	/* �����`�F�b�N */
	if (argc != 1) {
		goto sdio_get_info;
	}

	/* CCCR(0x00) Read */
	if(io_sd_read_direct(fn,0x00,raw,&regbyte) == SD_ERR){
		puts("CMD52_R ERROR\n");
		return -1;
	}

	/* CCCR Format Version number */
	printf("=== CCCR Format Version Number === \n");
	if((regbyte & 0x0F) == 0x00){
		printf("CCCR/FBR defined in SDIO Version 1.00 \n");
	}
	else if((regbyte & 0x0F) == 0x01){
		printf("CCCR/FBR defined in SDIO Version 1.10 \n");
	}
	else if((regbyte & 0x0F) == 0x02){
		printf("CCCR/FBR defined in SDIO Version 2.00 \n");
	}
	else if((regbyte & 0x0F) == 0x03){
		printf("CCCR/FBR defined in SDIO Version 3.00 \n");
	}
	else {
		printf("Reserved for Future Use \n");
	}

	/* SDIO Specification Revison Number */
	printf("\n=== SDIO Specification Revison Number === \n");
	if((regbyte >> 4) == 0x00){
		printf("SDIO Specification Version 1.00 \n");
	}
	else if((regbyte >> 4) == 0x01){
		printf("SDIO Specification Version 1.10 \n");
	}
	else if((regbyte >> 4) == 0x02){
		printf("SDIO Specification Version 1.20 \n");
	}
	else if((regbyte >> 4) == 0x03){
		printf("SDIO Specification Version 2.00 \n");
	}
	else if((regbyte >> 4) == 0x04){
		printf("SDIO Specification Version 3.00 \n");
	}
	else {
		printf("Reserved for Future Use \n");
	}


	/* CCCR(0x01) Read */
	if(io_sd_read_direct(fn,0x01,raw,&regbyte) == SD_ERR){
		puts("CMD52_R ERROR\n");
		return -1;
	}

	/* SD Format Version Number */
	printf("\n=== SD Format Version Number === \n");
	if((regbyte & 0x0F) == 0x00){
		printf("Physical Layer Specification Version 1.01 \n");
	}
	else if((regbyte & 0x0F) == 0x01){
		printf("Physical Layer Specification Version 1.10 \n");
	}
	else if((regbyte & 0x0F) == 0x02){
		printf("Physical Layer Specification Version 2.00 \n");
	}
	else if((regbyte & 0x0F) == 0x03){
		printf("Physical Layer Specification Version 3.0x \n");
	}
	else {
		printf("Reserved for Future Use \n");
	}

	/* SD Format Version Number */
	printf("\n=== Function Number === \n");
	sdio_fn_num = io_sd_get_fn_num();
	printf("function number = %d\n", sdio_fn_num);

	/* CCCR(0x02) Read */
	if(io_sd_read_direct(fn,0x02,raw,&regbyte) == SD_ERR){
		puts("CMD52_R ERROR\n");
		return -1;
	}

	/* Enable Function */
	if( (regbyte & 0x02) == 0x02){
		printf("function1 : enable\n");
	}
	else{
		printf("function1 : disable\n");
	}

	if( (regbyte & 0x04) == 0x04){
		printf("function2 : enable\n");
	}
	else{
		printf("function2 : disable\n");
	}

	if( (regbyte & 0x08) == 0x08){
		printf("function3 : enable\n");
	}
	else{
		printf("function3 : disable\n");
	}

	if( (regbyte & 0x10) == 0x10){
		printf("function4 : enable\n");
	}
	else{
		printf("function4 : disable\n");
	}

	if( (regbyte & 0x20) == 0x20){
		printf("function5 : enable\n");
	}
	else{
		printf("function5 : disable\n");
	}

	if( (regbyte & 0x40) == 0x40){
		printf("function6 : enable\n");
	}
	else{
		printf("function6 : disable\n");
	}

	if( (regbyte & 0x80) == 0x80){
		printf("function7 : enable\n");
	}
	else{
		printf("function7 : disable\n");
	}


	/* CCCR(0x07) Read */
	if(io_sd_read_direct(fn,0x07,raw,&regbyte) == SD_ERR){
		puts("CMD52_R ERROR\n");
		return -1;
	}

	/* Bus Width Setting */
	printf("\n=== Bus Width === \n");
	if( (regbyte & 0x03) == 0x00){
		printf("1-bit \n");
	}
	else if( (regbyte & 0x03) == 0x01){
		printf("Reserved \n");
	}
	else if( (regbyte & 0x03) == 0x02){
		printf("4-bit bus \n");
	}
	else{
		printf("8-bit bus \n");
	}

	/* CCCR(0x08) Read */
	if(io_sd_read_direct(fn,0x08,raw,&regbyte) == SD_ERR){
		puts("CMD52_R ERROR\n");
		return -1;
	}

	/* Low Speed Card? */
	printf("\n=== Low Speed Card? === \n");
	if( (regbyte & SDIO_CCCR_LSC) == SDIO_CCCR_LSC){
		printf("This SDIO Card is a Low-Speed card.\n");

		if((regbyte & SDIO_CCCR_4BLS) == SDIO_CCCR_4BLS){
			printf("This SDIO Card Support 4-bit data transfer.\n");
		}
	}
	else{
		printf("This SDIO Card is a Full-Speed card.\n");
	}

	/* Support Multiple Block Transfer ? */
	if((regbyte & 0x02)== 0x02){
		printf("Support Multiple Block Transfer.\n");
	}
	else{
		printf("Not support Multiple Block Transfer.\n");
	}


	puts("GET_INFO Normal End. \n");
	return 0; /* Normal End */

sdio_get_info:
	printf("usage: %s<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;
}

/*******************************************************************************
 * ID          :
 * Outline     : help of get info
 * Include     :
 * Declaration : int help_sdio_get_info(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_get_info(void)
{
	printf("usage: GET_INFO<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_EXTENDED�R�}���h�̎��s(Read,�o�C�g�P��)
 * Include     :
 * Declaration : int cmd_sdio_cmd53_byt_r(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : �o�C�g�P�ʂ̃��[�h( 1�`512�o�C�g�̃��[�h )
*******************************************************************************/
int cmd_sdio_cmd53_byt_r(int argc, char **argv)
{
	unsigned int fn;
	int i,j,roop_num;
	long byte;
	int cnt=0;	/* �ǂݏo���� */
	RW_EXTENDED_ARG ext_arg;
	unsigned char *ptr;
	int offset;
	long base_addr;

	ext_arg.bit.rw_flag=0;			/* read */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */

	memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));

	if (argc != 4) {
		goto sdio_cmd53_r_usage;
	}

	/* Check Function Number */
	fn = atoi(argv[1]);
	if(fn > 7){
		goto sdio_cmd53_r_usage;
	}

	ext_arg.bit.function_number = fn;


	/* Check ByteNum */
	byte = atoi(argv[3]);
	if((byte < 0) || (byte > 512)){
		goto sdio_cmd53_r_usage;
	}

	ext_arg.bit.count = byte;

	/* Check Register Address */
	ext_arg.bit.register_address = atoi(argv[2]);
	if( ext_arg.bit.register_address > 0x1FFFF ){
		goto sdio_cmd53_r_usage;
	}

	/* �͈͓�? */
	if( (ext_arg.bit.register_address + byte) > 0x20000 ){
		goto sdio_cmd53_r_usage;
	}


	/* Send CMD53 (READ/BYTE) */
	if(io_sd_read_extneded(&ext_arg,buff) != SD_OK){
		puts("CMD53 error\n");
		return -1;
	}

	ptr = (unsigned char *)buff;


	roop_num = (byte + 16 + (ext_arg.bit.register_address & 0xF) -1)/16;
	offset = (ext_arg.bit.register_address & 0xF);
	base_addr = ext_arg.bit.register_address & 0x1FFF0;


	cnt = 0;
	for(j=0; j < roop_num; j++){
		printf("%06X : ", j*16 + base_addr);
		for(i=0; i < 16; i++){
			if( (j == 0) && (i < offset) ){
				printf("-- "); /* �ŏ��̒[�� */
			}
			else if( cnt >= byte ){ /* �w��o�C�g���ȏ�ǂݏo������"-- " */
				printf("-- ");
			}
			else{
				printf("%02x ",*ptr++);
				cnt++;
			}
		}
		printf("\n");
	}

	puts("CMD53_R(Byte Transfer) Normal End. \n");
	return 0; /* Normal End */

sdio_cmd53_r_usage:
	printf("usage: %s FunctionNumber(0~7) StartAddress(0~0x1FFFF) ByteNum(1~512)<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;	/* error */

}

/*******************************************************************************
 * ID          :
 * Outline     : help of CMD53_BYT_R
 * Include     :
 * Declaration : int help_sdio_cmd53_byt_r(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_cmd53_byt_r(void)
{
	printf("usage:CMD53_BYT_R FunctionNumber(0~7) StartAddress(0~0x1FFFF) ByteNum(1~512)<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_EXTENDED�R�}���h�̎��s(Write,�o�C�g�P��)
 * Include     :
 * Declaration : int cmd_sdio_cmd53_byt_w(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : eroror end
 * Note        : �e�X�g�f�[�^���o�C�g�P�ʂ̃��C�g( 1�`512�o�C�g�̃��C�g )
*******************************************************************************/
int cmd_sdio_cmd53_byt_w(int argc, char **argv)
{

	unsigned int fn;
	int i;
	long byte;
	RW_EXTENDED_ARG ext_arg;

	ext_arg.bit.rw_flag=1;			/* write */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */


	memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));

	if (argc != 4) {
		goto sdio_cmd53_w_usage;
	}

	/* Check Function Number */
	fn = atoi(argv[1]);
	if(fn > 7){
		goto sdio_cmd53_w_usage;
	}
	ext_arg.bit.function_number = fn;

	/* Check ByteNum */
	byte = atoi(argv[3]);
	if((byte < 0) || (byte > 512)){
		goto sdio_cmd53_w_usage;
	}

	ext_arg.bit.count = byte;

	/* Check Start Address */
	ext_arg.bit.register_address = atoi(argv[2]);
	if( ext_arg.bit.register_address > 0x1FFFF ){
		goto sdio_cmd53_w_usage;
	}

	/* �͈͓�? */
	if( (ext_arg.bit.register_address + byte) > 0x20000 ){
		goto sdio_cmd53_w_usage;
	}

	/* make write deta */
	for(i=0; i < 512 ; i++){
		buff[i] = i;
	}

	/* Send CMD53 (WRITE/BYTE) */
	if(io_sd_write_extneded(&ext_arg, &buff[0]) != SD_OK){
		puts("CMD53(Byte Write) error\n");
		return -1;
	}

	puts("CMD53_W(Byte Transfer) Normal End. \n");
	return 0; /* Normal End */

sdio_cmd53_w_usage:
	printf("usage: %s FunctionNumber(0~7) StartAddress(0~0x1FFFF) ByteNum(1~512)<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;	/* error */

}

/*******************************************************************************
 * ID          :
 * Outline     : help of CMD53_BYT_W
 * Include     :
 * Declaration : int help_sdio_cmd53_byt_w(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_cmd53_byt_w(void)
{
	printf("usage:CMD53_BYT_W FunctionNumber(0~7) StartAddress(0~0x1FFFF) ByteNum(1~512)<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_EXTENDED�R�}���h�̎��s(Read,�u���b�N�P��)
 * Include     :
 * Declaration : int cmd_sdio_cmd53_blk_r(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : �u���b�N�P�ʒP�ʂ̃��[�h
 *             : SDIO�J�[�h����CMD53�ɂ��u���b�N�]�����Ή��̏ꍇ
 *             : �{�֐��͐���ɓ��삵�܂���B
 *             :
*******************************************************************************/
int cmd_sdio_cmd53_blk_r(int argc, char **argv)
{
	unsigned int fn;
	long block_num;
	RW_EXTENDED_ARG ext_arg;

	ext_arg.bit.rw_flag=0;			/* read */
	ext_arg.bit.block_mode=1;		/* block transfer */
	ext_arg.bit.op_code=1;			/* incrementing address */

	memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));

	if (argc != 4) {
		goto sdio_cmd53_blk_r_usage;
	}

	/* Check Function Number */
	fn = atoi(argv[1]);
	if(fn > 7){
		goto sdio_cmd53_blk_r_usage;
	}
	ext_arg.bit.function_number = fn;


	/* �u���b�N��(���10��) */
	block_num = atoi(argv[3]);
	if((block_num < 0) || (block_num > 10)){
		goto sdio_cmd53_blk_r_usage;
	}
	ext_arg.bit.count = block_num;


	/* Check Register Address */
	ext_arg.bit.register_address = atoi(argv[2]);
	if( ext_arg.bit.register_address > 0x1FFFF ){
		goto sdio_cmd53_blk_r_usage;
	}

	/* Send CMD53 (READ/Block) */
	if(io_sd_read_extneded(&ext_arg,buff) != SD_OK){
		puts("CMD53 BLOCK READ ERROR!\n");
		return -1;
	}

	puts("CMD53_R(BLOCK Transfer) Normal End. \n");
	return 0; /* Normal End */

sdio_cmd53_blk_r_usage:
	printf("usage: %s FunctionNumber(0~7) StartAddress(0~0x1FFFF) BlockNum(1~10)<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;	/* error */

}

/*******************************************************************************
 * ID          :
 * Outline     : help of CMD53_BLK_R
 * Include     :
 * Declaration : int help_sdio_cmd53_blk_r(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_cmd53_blk_r(void)
{
	printf("usage:CMD53_BLK_R FunctionNumber(0~7) StartAddress(0~0x1FFFF) BlockNum(1~10)<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : IO_RW_EXTENDED�R�}���h�̎��s(Write,�u���b�N�P��)
 * Include     :
 * Declaration : int cmd_sdio_cmd53_blk_w(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : �u���b�N�P�ʒP�ʂ̃��C�g
 *             : SDIO�J�[�h����CMD53�ɂ��u���b�N�]�����Ή��̏ꍇ
 *             : �{�֐��͐���ɓ��삵�܂���B
 *             :
*******************************************************************************/
int cmd_sdio_cmd53_blk_w(int argc, char **argv)
{
	unsigned int fn;
	long block_num;
	RW_EXTENDED_ARG ext_arg;
	unsigned char *ptr;
	int i;
	int block_size=512;

	ext_arg.bit.rw_flag=1;			/* Write */
	ext_arg.bit.block_mode=1;		/* block transfer */
	ext_arg.bit.op_code=1;			/* incrementing address */


	memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));

	if (argc != 4) {
		goto sdio_cmd53_blk_w_usage;
	}

	/* Check Function Number */
	fn = atoi(argv[1]);
	if(fn > 7){
		goto sdio_cmd53_blk_w_usage;
	}
	ext_arg.bit.function_number = fn;


	/* �u���b�N��(���10��) */
	block_num = atoi(argv[3]);
	if((block_num < 0) || (block_num > 10)){
		goto sdio_cmd53_blk_w_usage;
	}
	ext_arg.bit.count = block_num;


	/* Check Register Address */
	ext_arg.bit.register_address = atoi(argv[2]);
	if( ext_arg.bit.register_address > 0x1FFFF ){
		goto sdio_cmd53_blk_w_usage;
	}

	/* make testdata */
	ptr =(unsigned char *)&buff[0];
	for(i=0; i< block_num*block_size; i++){
		*ptr++ = i;
	}

	/* Send CMD53 (WRITE/Block) */
	if(io_sd_write_extneded(&ext_arg, &buff[0]) != SD_OK){
		puts("CMD53 BLOCK WRITE ERROR! \n");
		return -1;
	}

	puts("CMD53_W(BLOCK Transfer) Normal End. \n");
	return 0; /* Normal End */

sdio_cmd53_blk_w_usage:
	printf("usage: %s FunctionNumber(0~7) StartAddress(0~0x1FFFF) BlockNum(1~10)<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;	/* error */

}

/*******************************************************************************
 * ID          :
 * Outline     : help of CMD53_BLK_W
 * Include     :
 * Declaration : int help_sdio_cmd53_blk_w(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_cmd53_blk_w(void)
{
	printf("usage:CMD53_BLK_W FunctionNumber(0~7) StartAddress(0~0x1FFFF) BlockNum(1~10)<Enter>\n");
	fflush(stdout);
	return 0;
}


/*******************************************************************************
 * ID          :
 * Outline     : SET_BUS_WIDTH
 * Include     :
 * Declaration : int cmd_sdio_set_bus_width(int argc, char **argv);
 *             :
 * Description : �o�X���̕ύX
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        :
 *             :
 *             : SDIO> SET_BUS_WIDTH 1<ENTER> -> Bus width : 4bit
 *             : SDIO> SET_BUS_WIDTH 0<ENTER> -> Bus width : 1bit
*******************************************************************************/
int cmd_sdio_set_bus_width(int argc, char **argv)
{
	int bus_width;
	unsigned char reg;
	unsigned int fn=0;		/* function0 */
	unsigned int addr=7;	/* Bus Interface Control Register(CCCR)*/
	int raw=0;				/* read after write */


	if (argc != 2) {
		goto sdio_cmd_set_bus_witdh_usage;
	}

	/* �o�X���ݒ�̎擾 */
	bus_width = atoi(argv[1]);


	/*  Bus Interface Control Register�̃��[�h */
	if(io_sd_read_direct(fn,addr,raw,&reg) != SD_OK){
		puts("CMD52_R ERROR\n");
	}

	/*�o�X��1�r�b�g�ݒ�̏ꍇ */
	if(bus_width == 0){
		reg = (reg & 0xFC);
		io_sd_change_bus_width(SDIO_1BIT_TRN);
	}
	/*�o�X��4�r�b�g�ݒ�̏ꍇ */
	else if(bus_width == 1){
		reg = (reg & 0xFC) | 0x02;
		io_sd_change_bus_width(SDIO_4BIT_TRN);
	}
	else{
		goto sdio_cmd_set_bus_witdh_usage;
	}

	/* Bus Interface Control Register�ւ̃��C�g */
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	return 0;	/* normal end */

sdio_cmd_set_bus_witdh_usage:
	printf("usage: %s BusWidth(0:1bit,1:4bit)<Enter>\n",argv[0]);
	fflush(stdout);
	return -1;

}

/*******************************************************************************
 * ID          :
 * Outline     : help of SET_BUS_WIDTH
 * Include     :
 * Declaration : int help_sdio_set_bus_width(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_set_bus_width(void)
{

	printf("usage: SET_BUS_WIDTH BusWidth(0:1bit,1:4bit)<Enter>\n");
	fflush(stdout);

	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : SET BLOCK_SIZE
 * Include     :
 * Declaration : int cmd_sdio_set_block_size(int argc, char **argv);
 *             :
 * Description : �o�X���̕ύX �u���b�N�T�C�Y�̕ύX
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : Function1�̃u���b�N�T�C�Y��ύX
 *             :
*******************************************************************************/
int cmd_sdio_set_block_size(int argc, char **argv)
{

	int block_size;
	unsigned char reg;
	unsigned int fn=0;		/* function0 */
	unsigned int addr;
	int raw=0;				/* read after write */

	if (argc != 2) {
		goto sdio_cmd_set_blcok_size_usage;
	}

	/* �u���b�N�T�C�Y�ݒ�̎擾 */
	block_size = atoi(argv[1]);

	if((block_size <= 0) || (block_size > 0x200)){
		goto sdio_cmd_set_blcok_size_usage;
	}

	/* FBR�փu���b�N�T�C�Y�ݒ� */
	addr = 0x110;
	reg = (unsigned char)(block_size & 0x000000FF);
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	addr = 0x111;
	reg = (unsigned char)( ((block_size & 0x0000FF00) >> 8)) ;
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	/* SDIO�u���b�N�T�C�Y��ύX	*/
	io_sd_set_block_size((unsigned int)block_size);

	return 0;	/* normal end */

sdio_cmd_set_blcok_size_usage:
	printf("usage: %s BlockSize(1-2048[byte])<Enter>\n",argv[0]);
	fflush(stdout);
	return -1;
}






int cmd_sdio_exit(int argc, char **argv)
{
	int flag,i=0;
	unsigned char reg;
	unsigned int fn=1;		/* function0 */
		long addr;
	long tmp;
	unsigned char readdata,readdata1,readdata2,readdata3;
	RW_EXTENDED_ARG ext_arg;
	unsigned char *ptr;
	unsigned short	info1;

    if (argc != 1) {
		goto sdio_cmd_exit_usage;
	}

	/* �u���b�N�T�C�Y�ݒ�̎擾 */
	flag = atoi(argv[1]);
    rdFlag = 0;
	while(!rdFlag);
	{
	    // issue the read  for the recvd data

	}
    puts("rd-isr\n");

	// read int register
	addr = 0x04;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
	io_sd_clear_sdio_int();
	printf("int1\n");
	addr = 0x05;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata1) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
	printf("int2\n");
	addr = 0x06;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata2) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
	printf("int3\n");
		addr = 0x07;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata3) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}

	printf("int4\n");

	printf("Isr:%x-%x-%x\n",readdata,readdata1,readdata2);
		addr = 0x1C;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
	printf("int5\n");
		addr = 0x1D;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata1) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
		addr = 0x1E;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata2) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
			addr = 0x1F;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata3) == SD_ERR){
		puts("CMD52_R ERROR\n");

	}
	printf("Count:%x-%x-%x\n",readdata,readdata1,readdata2);
	// read the data
	memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));
	ext_arg.bit.rw_flag=0;			/* read */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */
	ext_arg.bit.function_number = fn;

	ext_arg.bit.count = readdata;

	/* Check Register Address */
	ext_arg.bit.register_address = 0x00;


	/* Send CMD53 (READ/BYTE) */
	if(io_sd_read_extneded(&ext_arg,buff) != SD_OK){
		puts("CMD53 error\n");
		return -1;
	}

	ptr = (unsigned char *)buff;
	for(i=0;i<readdata;i++)
	{
	   printf("%c",*ptr++);
	}

    sdio_user_details();
	io_sd_enable_sdio_int();
	/* FBR�փu���b�N�T�C�Y�ݒ� */
    sdio_cmd_exit_usage:
	printf("\nusage: %s BlockSize(1-2048[byte])<Enter>\n",argv[0]);
	fflush(stdout);
	return -1;
}


int
cmd_sdio_rxtest(int argc, char **argv)
{
   int length=0,i=0;
	    unsigned char reg;
	    unsigned int fn=1;		/* function0 */
	    long addr;
	    long tmp;
	    unsigned char readdata,readdata1,readdata2,readdata3;
	    RW_EXTENDED_ARG ext_arg;
	    unsigned char *ptr;
	    unsigned short	info1;

	    ext_arg.bit.rw_flag=0;			/* read */
	    ext_arg.bit.block_mode=1;		/* bytes access */
	    ext_arg.bit.op_code=1;			/* incrementing address */
	    ext_arg.bit.function_number = fn;
		ext_arg.bit.register_address = 0x00;
	while(1)
	{
	   //puts("Rd-Wait\n");
       while(!rdFlag);
	rdFlag =0;
    // read int register
	    addr = 0x04;
	    if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
		  puts("CMD52_R ERROR\n");
		}
	    io_sd_clear_sdio_int();

		addr = 0x1C;
	    if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
		   puts("CMD52_R ERROR\n");

	    }

		addr = 0x1D;
	    if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata1) == SD_ERR){
		   puts("CMD52_R ERROR\n");

	    }
#if 0
		addr = 0x1E;
	    if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata2) == SD_ERR){
		   puts("CMD52_R ERROR\n");

	    }
		addr = 0x1F;
	    if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata3) == SD_ERR){
		   puts("CMD52_R ERROR\n");

	    }
	    //printf("Count:%x-%x-%x\n",readdata,readdata1,readdata2);
#endif
        length=(readdata |(readdata1 << 8));
        printf("\nCount Rcvd:%d\n",length);
	    // read the data
	    //memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));
	    //ext_arg.bit.rw_flag=0;			/* read */
	    //ext_arg.bit.block_mode=1;		/* bytes access */
	    //ext_arg.bit.op_code=1;			/* incrementing address */
	    //ext_arg.bit.function_number = fn;

	    ext_arg.bit.count = length/512;

	    /* Check Register Address */
	    //ext_arg.bit.register_address = 0x00;


	    /* Send CMD53 (READ/BYTE) */
	    if(io_sd_read_extneded(&ext_arg,buff) != SD_OK)
		{
		   puts("CMD53 error\n");
		   return -1;
	    }

	    ptr = (unsigned char *)buff;
	    for(i=0;i<length;i++)
	    {
		   printf("%x ",*ptr++);
	    }

        io_sd_enable_sdio_int();


		//fflush(stdout);
		}


	return 0;



}


int
cmd_sdio_txtest(int argc, char **argv)
{
	int i =0,block_no=0,times=1;
    unsigned char* ptr;
	puts("Tx-Txteset\n");
	ptr = (unsigned char *)buff;
	block_no = atoi(argv[1]);
	times = atoi(argv[2]);
	printf("Tx-Txteset:%d-%d-%d\n",512,block_no,times);
	for(i=0;i<255;i++)
	{
	   *ptr++ = i;
	   //buff[i]=i;
	}
	for(i=255;i<512;i++)
	{
	   *ptr++ = 11;
	   //buff[i]=i;
	}
    for(i=512;i<769;i++)
	{
	   *ptr++ = 12;
	   //buff[i]=i;
	}
	for(i=769;i<1024;i++)
	{
	   *ptr++ = 22;
	   //buff[i]=i;
	}
	// send 10 times
	//for(i=0;i<times;i++)
	{
	    //dataTxBlock(buff, 512,block_no);
		dataTxBlockNtimes((char*)buff, 512,block_no,times);
	}
	//printf("\nusage: %s BlockSize(1-2048[byte])<Enter>\n",argv[0]);
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : help of SET_BLOCK_SIZE
 * Include     :
 * Declaration : int help_sdio_set_block_size(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_set_block_size(void)
{

	printf("usage: SET_BLOCK_SIZE BlockSize(1-2048[byte])<Enter>\n");
	fflush(stdout);

	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : help of SET_BLOCK_SIZE
 * Include     :
 * Declaration : int help_sdio_set_block_size(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_exit(void)
{

	printf("usage: SET_BLOCK_SIZE BlockSize(1-2048[byte])<Enter>\n");
	fflush(stdout);

	return 0;
}

int help_sdio_txtest(void)
{
return 0;
}
int help_sdio_rxtest(void)
{
return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : Mount SDIO Card
 * Include     :
 * Declaration : int cmd_sdio_mount(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : 1
*******************************************************************************/
int cmd_sdio_mount(int argc, char **argv)
{
	/* �����`�F�b�N */
	if (argc != 1) {
		goto sdio_mount;
	}

	/* ==== �}�E���g���� ==== */
	puts("[SD] card mount...");

	if( g_io_sddev_sdio_cd != 1 ){
		puts("no SD card!!");
		return -1;
	}

	if(io_sd_mount() == SD_OK){
		puts("[SD] card mount OK");
	}
	else{
		puts("[SD] card mount ERROR\n");
		return -1;
	}

	printf("\n");
	fflush(stdout);
	return 0; /* Normal End */

sdio_mount:
	printf("usage: %s<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;
}

/*******************************************************************************
 * ID          :
 * Outline     : help of att
 * Include     :
 * Declaration : int help_sdio_mount(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_mount(void)
{
	printf("usage: MOUNT<Enter>\n");
	fflush(stdout);
	return 0;
}

/*******************************************************************************
 * ID          :
 * Outline     : Unmount SDIO Card
 * Include     :
 * Declaration : int cmd_sdio_unmount(int argc, char **argv);
 *             :
 * Description :
 * Argument    : int  argc ;   �P�ꐔ
 *             : char **argv;
 *             :
 * Return Value:  0 : normal end
 *             : -1 : error end
 * Note        : 1
*******************************************************************************/
int cmd_sdio_unmount(int argc, char **argv)
{

	/* �����`�F�b�N */
	if (argc != 1) {
		goto sdio_unmount;
	}

	io_sd_unmount();

	printf("[SD] Card unmount OK\n");
	fflush(stdout);
	return 0; /* Normal End */

sdio_unmount:
	printf("usage: %s<Enter>\n", argv[0]);
	fflush(stdout);
	return -1;
}

/*******************************************************************************
 * ID          :
 * Outline     : help of unmount
 * Include     :
 * Declaration : int help_sdio_unmount(void)
 *             :
 * Description :
 * Argument    : none
 * Return Value: none
 *             :
 * Note        : None
*******************************************************************************/
int help_sdio_unmount(void)
{
	printf("usage: UNMOUNT<Enter>\n");
	fflush(stdout);
	return 0;
}


/*******************************************************************************
 * ID          :
 * Outline     : Enable Function1
 * Include     :
 * Declaration : static int sdio_set_func1_enable(void)
 *             :
 * Description :
 * Argument    : none
 *             :
 * Return Value:  0: normal end
 *             : -1: error end
 *             :
 * Note        : None
*******************************************************************************/
static int sdio_set_func1_enable(void)
{
	unsigned int fn;
	unsigned int addr;
	unsigned char writedata;
	int raw;			/* read after write */

	/* CCCR��2�Ԓn��2�����C�g -> Enable Function1 */
	fn = 0;
	addr = 0x2;
	writedata = 0x2;
	raw = 0;
	if(io_sd_write_direct(fn, addr,raw,&writedata) != SD_OK){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	return 0; /* normal end */
}

/*******************************************************************************
 * ID          :
 * Outline     : Funciton1�̃u���b�N�T�C�Y�̐ݒ�
 * Include     :
 * Declaration : static int sdio_set_blk_sz(int block_size);
 *             :
 * Description : 1. FBR��I/O block size for Function1�ւ̃u���b�N�T�C�Y�ݒ�
 *             : 2. �u���b�N�T�C�Y�Ǘ��ϐ����X�V
 * Argument    : int block_size; �u���b�N�T�C�Y
 *             :
 * Return Value:  0: normal end
 *             : -1: error end
 *             :
 * Note        :
*******************************************************************************/
static int sdio_set_blk_sz(int block_size)
{

	unsigned int fn;
	unsigned int addr;
	unsigned char reg;
	int raw;			/* read after write */

	fn = 0;
	raw =0;
	addr = 0x110;

	reg = (unsigned char)(block_size & 0x000000FF);
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	addr = 0x111;
	reg = (unsigned char)( ((block_size & 0x0000FF00) >> 8)) ;
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
		return -1;
	}

	/* SDIO�u���b�N�T�C�Y��ύX	*/
	io_sd_set_block_size((unsigned int)block_size);

	return 0; /* normal end */
}



int sdio_cmd53_byt_w(char* DataBuff, int len)
{

	unsigned int fn;
	int i;
	long byte;
	RW_EXTENDED_ARG ext_arg;

	ext_arg.bit.rw_flag=1;			/* write */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */


	memset(buff,0xFF, sizeof(buff)/sizeof(unsigned long));

	ext_arg.bit.function_number = 1;

	ext_arg.bit.count = len;

	/* Check Start Address */
	ext_arg.bit.register_address = 0x00;

	memcpy(buff,DataBuff,len);

	/* Send CMD53 (WRITE/BYTE) */
	if(io_sd_write_extneded(&ext_arg, &buff[0]) != SD_OK){
		puts("CMD53(Byte Write) error\n");
		return -1;
	}

	//puts("CMD53_W(Byte Transfer) Normal End. \n");
	return 0; /* Normal End */
}


void
dataTxBlockNtimes(char* buff, int block_size,int block_num,int times)
{
    int i=0;
   	RW_EXTENDED_ARG ext_arg;
	ext_arg.bit.rw_flag=1;			/* Write */
	ext_arg.bit.block_mode=1;		/* block transfer */
	ext_arg.bit.op_code=1;			/* incrementing address */


	ext_arg.bit.function_number = 1;

	ext_arg.bit.count = block_num;


	/* Check Register Address */
	ext_arg.bit.register_address = 0x00;
    for(i=0;i<times;i++)
	{
	   //printf("\nNo:%d\n",i);
		/* Send CMD53 (WRITE/Block) */
	    if(io_sd_write_extneded(&ext_arg, &buff[0]) != SD_OK){
		   puts("CMD53 BLOCK WRITE ERROR! \n");
		   break;
		}

	}
	printf("\n%dKBTransferred\n",((i*block_num*512)/1024));


}


int
GsSdio_RxDataLength()
{
    int length=0;
    unsigned int fn=1;
	long addr;
	unsigned char writedata,readdata,readdata1,readdata2;

	// read count reg
	addr = 0x1C;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR){
	    puts("CMD52_R ERROR\n");
	}
	addr = 0x1D;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata1) == SD_ERR){
		puts("CMD52_R ERROR\n");
	}
	length = readdata | (readdata1 << 8);
    return length;
}

int
readResponseFromCard(char* dBuff, int length)
{
    RW_EXTENDED_ARG ext_arg;
    // read the data
	ext_arg.bit.rw_flag=0;			/* read */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */
	ext_arg.bit.function_number = 1;

	ext_arg.bit.count = length;

	    /* Check Register Address */
	ext_arg.bit.register_address = 0x00;


	/* Send CMD53 (READ/BYTE) */
	if(io_sd_read_extneded(&ext_arg,dBuff) != SD_OK){
		   puts("CMD53 error\n");
		   return -1;
	    }
	return 0;


}

int
GsSdio_Enable()
{
	unsigned int fn;
	long addr;
	unsigned char writedata,readdata;
	int raw;
	// enable the IO for fun1
	/* Send CMD52 (WRITE) */
    fn=0;
    addr = ADDR_CCCR_IOENABLE;
    raw = TRUE;
	writedata = 0x02;
	if(io_sd_write_direct((unsigned int)fn, (unsigned int)addr,(unsigned int)raw,&writedata) == SD_ERR)
	{
	    // if it failed write again
		io_sd_write_direct((unsigned int)fn, (unsigned int)addr,(unsigned int)raw,&writedata);
	}

	/* Send CMD52 (READ) */
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR)
	{
	    // if it failed read again
		io_sd_read_direct((unsigned int)fn, (unsigned int)addr,0,&readdata);		puts("CMD52_R ERROR\n");
	}
    if(readdata != writedata)
	{
	   return -1;
	}
	return 0;
}

int
GsSdio_IntEnable()
{
	unsigned int fn;
	long addr;
	unsigned char writedata,readdata;
	int raw=0;
   //printf("IO enabled\n");
    // Enable interrupts
    fn=0;
    addr = ADDR_CCCR_INTENABLE;
	writedata = 0x03;
	if(io_sd_write_direct((unsigned int)fn, (unsigned int)addr,(unsigned int)raw,&writedata) == SD_ERR)
	{
	    // write again
		io_sd_write_direct((unsigned int)fn, (unsigned int)addr,(unsigned int)raw,&writedata);
	}

	/* Send CMD52 (READ) */
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR)
	{
		io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata);
	}
    if(readdata != writedata)
	{
	    return -1;
	}
	return 0;
}
int
GsSdio_Disable()
{
}
int
GsSdio_IntDisable()
{
}

int
GsSdio_DataRead(char* dbuff, int length)
{
    unsigned int LenRemain=0,cnt=0,cntMode=0;
	RW_EXTENDED_ARG ext_arg;
	memset(dbuff,0xFF, sizeof(dbuff)/sizeof(unsigned long));
	ext_arg.bit.rw_flag=0;			/* read */
	ext_arg.bit.block_mode=0;		/* bytes access */
	ext_arg.bit.op_code=1;			/* incrementing address */
	ext_arg.bit.function_number = 1 ;

	ext_arg.bit.count = length;
	ext_arg.bit.register_address = 0x00;

	if(length>512) // more than 512 use block mode
	{
	    cnt = length/512;
		cntMode = length%512;
		//printf("\n cnt:%d Mode:%d\n",cnt,cntMode);
	    ext_arg.bit.block_mode=1;		/* bytes access */
		ext_arg.bit.count = cnt;
	    LenRemain= cntMode;
	}
    /* Send CMD53 (READ/BYTE) */
	if(io_sd_read_extneded(&ext_arg,dbuff) != SD_OK)
	{
		return 0;
    }
    if(LenRemain)
	{
	    //printf("\nLengthR:%x\n",LenRemain);
	    ext_arg.bit.block_mode=0;		/* bytes access */
		ext_arg.bit.count = LenRemain;
		//LenRemain= 0;
		/* Send CMD53 (READ/BYTE) */
        if(io_sd_read_extneded(&ext_arg,&dbuff[cnt*512]) != SD_OK)
		{
	        return (512*cnt);
        }
	}
	return length;
}

int
GsSdio_IntClear()
{
    unsigned int fn;
	long addr;
	unsigned char readdata;
    // read int register to clear card intr
	fn = 1;
	addr = 0x04;
	if(io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata) == SD_ERR)
	{
		// read again
		io_sd_read_direct((unsigned int)fn, (unsigned int)addr, 0, &readdata);
	}
	io_sd_clear_sdio_int();	    // clear sd intr
	return 0;
}
int
GsSdio_BlockSizeSet(int block_size)
{
    unsigned int fn;
	long addr;
	unsigned char reg;
	int raw;
    fn=0;
	addr = 0x110;
	//block_size = 0x200;
	raw = 0;
	reg = (unsigned char)(block_size & 0x000000FF);
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
	}

	addr = 0x111;
	reg = (unsigned char)( ((block_size & 0x0000FF00) >> 8)) ;
	if(io_sd_write_direct(fn, addr,raw,&reg) != SD_OK){
		puts("CMD52_W ERROR\n");
	}

	/* SDIO�u���b�N�T�C�Y��ύX	*/
	io_sd_set_block_size((unsigned int)block_size);
	//printf("IO Blk sizeenabled\n");
	return 0;

}
/* End of File */
