/******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2013 Renesas Electronics Corporation. All rights reserved. 
**************************** Technical reference data **************************
*   System Name : SH7269 SDIO HOST Sample Program
*   File Name   : sdio.h
*   Abstract    : SDIO HOST driver sample header file
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.08.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.04 Release00).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : May.28,2013 Ver.1.00.00
*******************************************************************************/
#ifndef _SDIO_H_
#define _SDIO_H_

#include "sdio_if.h"

/* ==== SDHI register address ==== */
struct st_sdhi{
	_UWORD SD_CMD;
	_UWORD SD_PORTSEL;
	_UWORD SD_ARG0;
	_UWORD SD_ARG1;
	_UWORD SD_STOP;
	_UWORD SD_SECCNT;
	_UWORD SD_RESP0;
	_UWORD SD_RESP1;
	_UWORD SD_RESP2;
	_UWORD SD_RESP3;
	_UWORD SD_RESP4;
	_UWORD SD_RESP5;
	_UWORD SD_RESP6;
	_UWORD SD_RESP7;
	_UWORD SD_INFO1;
	_UWORD SD_INFO2;
	_UWORD SD_INFO1_MASK;
	_UWORD SD_INFO2_MASK;
	_UWORD SD_CLK_CTRL;
	_UWORD SD_SIZE;
	_UWORD SD_OPTION;
	_UBYTE wk0[2];
	_UWORD SD_ERR_STS1;
	_UWORD SD_ERR_STS2;
	_UDWORD SD_BUF0;
	_UWORD SDIO_MODE;
	_UWORD SDIO_INFO1;
	_UWORD SDIO_INFO1_MASK;
	_UBYTE wk2[0xd8-0x3a];
	_UWORD CC_EXT_MODE;
	_UBYTE wk3[0xe0-0xda];
	_UWORD SOFT_RST;
	_UWORD VERSION;
	_UBYTE wk4[0xf0-0xe4];
	_UWORD EXT_SWAP;
};

union st_r4{	/* Response Type : R4 */
	unsigned long all;
	struct{
		unsigned long c:1;		/* Set to 1 if Card is ready to operate after initialization */
		unsigned long nf:3;		/* Number of I/O Functions */
		unsigned long mp:1;		/* Memory Present */
		unsigned long dummy:3;	/* Stuff Bits:2bit, S18A:1bit */
		unsigned long ocr:24;	/* I/O OCR */
	}bit;
};

//#define SDHI	(*(volatile struct st_sdhi *)0xE803E000)
#define SDHI	(*(volatile struct st_sdhi *)0xE803E800)

/* ==== macro definitions ==== */
/* ---- media voltage ---- */
#define SD_VOLT_3_3					0x00100000ul 	/* for CMD5 */

/* ==== command type ==== */
/* ---- SD commands ---- */
#define CMD0						0u
#define CMD3						3u			/* SEND_RELATIVE_ADDR */
#define CMD7						7u			/* SELECT/DESELECT_CARD */
#define CMD5						0x0705u		/* IO_SEND_OP_COND */
#define CMD52_W						0x0434u		/* IO_WRITE_DIRECT */
#define CMD52_R						0x0434u		/* IO_READ_DIRECT  */
#define CMD53_W_BLOCK				0x6c35u		/* IO_WRITE_EXTENDED_BLOCK */
#define CMD53_W_BYTE				0x0c35u		/* IO_WRITE_EXTENDED_BYTE */
#define CMD53_R_BLOCK				0x7c35u		/* IO_READ_EXTENDED_BLOCK */
#define CMD53_R_BYTE				0x1c35u		/* IO_READ_EXTENDED_BYTE */

/* ---- info1 interrupt mask ---- */
#define SD_INFO1_MASK_DET_CD		0x0018u		/* Card Insert and Remove (CD) */
#define SD_INFO1_MASK_INS_CD		0x0010u		/* Card Insert (CD) */
#define SD_INFO1_MASK_REM_CD		0x0008u		/* Card Remove (CD) */
#define SD_INFO1_MASK_DATA_TRNS		0x0004u		/* Command sequence end */
#define SD_INFO1_MASK_TRNS_RESP		0x0005u		/* Command sequence end and Response end */
#define SD_INFO1_MASK_RESP			0x0001u		/* Response end */
#define SD_INFO1_MASK_DET_DAT3_CD	(SD_INFO1_MASK_DET_DAT3 | SD_INFO1_MASK_DET_CD)

/* ---- info2 interrupt mask ---- */
#define SD_INFO2_MASK_BWE			0x827fu		/* Write enable and All errors */
#define SD_INFO2_MASK_BRE			0x817fu		/* Read enable and All errors */
#define SD_INFO2_MASK_ERR			0x807fu		/* All errors */
#define SD_INFO2_MASK_ILA			0x8000u
#define SD_INFO2_MASK_CBSY			0x4000u		/* Command type register busy */
#define SD_INFO2_MASK_ERR6			0x0040u
#define SD_INFO2_MASK_ERR5			0x0020u
#define SD_INFO2_MASK_ERR4			0x0010u
#define SD_INFO2_MASK_ERR3			0x0008u
#define SD_INFO2_MASK_ERR2			0x0004u
#define SD_INFO2_MASK_ERR1			0x0002u
#define SD_INFO2_MASK_ERR0			0x0001u
#define SD_INFO2_MASK_WE			0x0200u		/* Write enable */
#define SD_INFO2_MASK_RE			0x0100u		/* Read enable */
#define SD_INFO2_MASK_RSV			0x837fu		/* reserved bit */

#define SD_INT_CMD_R_END			0x0001u		/* responce end interrupt */
#define SD_INT_CMD_A_END			0x0002u		/* access end interrupt */
#define SD_INT_CMD_BUFF				0x0004u		/* buffer ready */
#define SD_INT_CMD_ERR				0x0008u		/* info2 error interrupt */
#define SD_INT_CMD_IO				0x0010u		/* sdio interrupt */

/* ---- sdio_info interrupt mask ---- */
#define SDIO_INFO1_MASK_EXWT		0x8000u
#define SDIO_INFO1_MASK_EXPUB52		0x4000u
#define SDIO_INFO1_MASK_IOIRQ		0x0001u		/* interrupt from IO Card */
#define SDIO_INFO1_MASK_ALL			0xC001u		/* interrupt from IO Card */

/* ---- sdio mode ---- */
#define SDIO_MODE_C52PUB			0x0200u
#define SDIO_MODE_IOABT				0x0100u
#define SDIO_MODE_RWREQ				0x0004u
#define SDIO_MODE_IOMOD				0x0001u		/* interrupt from IO Card */

/* ---- cc extmode register ---- */
#define CC_EXT_MODE_DMASDRW			0x0002u

#endif	/* _SDIO_H_	*/

/* End of File */
