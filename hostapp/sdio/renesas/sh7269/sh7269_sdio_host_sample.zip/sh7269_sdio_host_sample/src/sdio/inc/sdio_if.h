/******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY,
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and
*   conditions found by accessing the following link:
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2013 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7269 SDIO HOST Sample Program
*   File Name   : sdio_if.h
*   Abstract    : SDIO HOST driver sample application header file
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.08.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.04 Release00).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description :
********************************************************************************
*   History     : May.28,2013 Ver.1.00.00
*******************************************************************************/
#ifndef _SDIO_IF_H_
#define _SDIO_IF_H_

/* ---- �f�[�^�]�����[�h�ݒ� ---- */
#define __SDIO_DMA_ENABLE__ 	0			/* 0: DMA�]������ */
											/* 1: DMA�]���L�� */

/* ---- SDHI���荞�݃��x���ݒ� ----	*/
#define INT_LEVEL_SDHI			15			/* SDHI interrupt level */

/* ---- function return value ---- */
#define SD_OK					0			/* OK */
#define SD_ERR					-1			/* general error */

/* ---- clock div ---- */
#define SD_CLK_100kHz			0x0080u		/* P1�� / 256 = 260KHz	 */
#define SD_CLK_400kHz			0x0040u		/* P1�� / 256 = 260KHz	 */
#define SD_CLK_33MHz			0x0000u		/* P1�� / 2   = 33.33MHz */
#define SD_CLK_16MHz			0x0001u		/* P1�� / 4   = 16.67MHz */
#define SD_CLK__9MHz			0x0002u		/* P1�� / 8   =  8.33MHz */

/* �n�C�X�s�[�h���삳����ꍇ�̃N���b�N��ݒ�	*/
#define SD_CLK_HISPEED			SD_CLK_33MHz	/* High-Speed Clock	*/
#define SD_CLK_FULLSPEED		SD_CLK_16MHz	/* Full-Speed Clock	*/
#define SD_CLK_LOWSPEED			SD_CLK_400kHz	/* Low-Speed Clock	*/


/* ---- SDIO Internal map ---- */
#define SDIO_AREA_CIA			0			/* function 0 */

/* ---- Card Capability(0x08) register ---- */
#define SDIO_CCCR_LSC			0x40u		/* card is low-speed cards */
#define SDIO_CCCR_4BLS			0x80u		/* 4-bit support for low-speed cards */

#define SDIO_RAW_1				1			/* write after read is enable 	*/
#define SDIO_RAW_0				0			/* write after read is disable  */

#define SDIO_4BIT_TRN 			1			/* 4bit transfer */
#define SDIO_1BIT_TRN 			0			/* 1bit transfer */

#define SDIO_FUNC_RDY 			1			/* Function��Ready */
#define SDIO_FUNC_BSY 			0			/* Function��Busy  */

#define SD_IO_POWER_INIT		0x01u		/* power on initialized */
#define SD_IO_POWER_OFF			0x00u		/* power off			*/

/* ==== Structure ==== */
typedef union{	/* CMD53(IO_RW_EXTENDED) Argument */
	unsigned long arg;
	struct{
		unsigned long rw_flag:1;			/* 0:read, 1:write */
		unsigned long function_number:3;	/* fuction0~fuction7 */
		unsigned long block_mode:1;			/* 0: Byte, 1:Block */
		unsigned long op_code:1;			/* 0:fixed address, 1:incrementing address */
		unsigned long register_address:17;	/* Register Address */
		unsigned long count:9;				/* Byte/Block Count */
	}bit;
}RW_EXTENDED_ARG;

/* ==== Prototype ==== */
/* ---- function ---- */
int		io_sd_init(void);
int		io_sd_mount(void);
void 	io_sd_unmount(void);
int		io_sd_send_cmd(unsigned short cmd,unsigned long arg);
int		io_sd_get_resp(unsigned long *resp);
int		io_sd_write_direct(unsigned int func,unsigned int reg_adr,unsigned int raw,unsigned char *data);
int		io_sd_read_direct(unsigned int func,unsigned int reg_adr,unsigned int raw,unsigned char *data);
int		io_sd_read_extneded(RW_EXTENDED_ARG *arg,unsigned long *data);
int		io_sd_write_extneded(RW_EXTENDED_ARG *arg,unsigned long *data);
int		io_sd_enable_sdio_int(void);
int		io_sd_disable_sdio_int(void);
void	io_sd_change_bus_width(int bus_width);
void 	io_sd_set_block_size(unsigned int block_size);
int 	io_sd_get_block_size(void);
int 	io_sd_get_fn_num(void);
int 	io_sd_is_func1_ready(void);
void
sdio_user_details();
void
io_sd_clear_sdio_int();


/* ---- interrupt function ---- */
void	io_sd_cd_hdr(void);
void	io_sd_access_hdr(void);
void	io_sd_io_hdr(void);

/* ---- user define function ---- */
void 	io_sddev_attach(void);
void 	io_sddev_detach(void);
void	io_sddev_cpg(void);
void	io_sddev_port(void);
int		io_sddev_wait(int msec);
int		io_sddev_init_dma(unsigned long buff,unsigned long reg,long cnt,int dir);
int		io_sddev_wait_dma_end(long cnt);
int		io_sddev_disable_dma(void);

#endif	/* _SDIO_IF_H_	*/

/* End of File */
