/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : bscsdram.c
*   Abstract    : SH7268/SH7269 Initial Settings
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "iodefine.h"

/* ==== Macro name definition ==== */
/* The address when writing in a SDRAM mode register */
#define	SDRAM_MODE		(*(volatile unsigned short *)(0xfffc5040))

/* ==== Prototype Declaration ==== */
void io_init_sdram(void);

#pragma section ResetPRG
/*******************************************************************************
 * ID          : 
 * Outline     : SDRAM 16 bit bus width connection settings
 * Include     : #include "iodefine.h"
 * Declaration : void io_init_sdram(void);
 * Description : A connection setup to SDRAM of CS3 space.
 *             : The PFC setting is set by bit manipulation not to change the PFC 
 *             : set value which is set by other process.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void io_init_sdram(void)
{	

	volatile int j = 150;				/* More than 200usec wait count @CKIO=66.67MHz*/
	
	/* ==== PFC settings ==== */
	PORT.PCCR2.BIT.PC8MD = 1u;			/* CS3#		*/
	PORT.PCCR1.BIT.PC7MD = 1u;			/* CKE		*/
	PORT.PCCR1.BIT.PC6MD = 1u;			/* CAS#		*/
	PORT.PCCR1.BIT.PC5MD = 1u;			/* RAS#		*/
	PORT.PCCR1.BIT.PC4MD = 1u;			/* DQMLU#	*/
	PORT.PCCR0.BIT.PC3MD = 1u;			/* DQMLL#	*/
	PORT.PCCR0.BIT.PC2MD = 1u;			/* RD/WR#	*/

	/* ==== More than 200us interval elapsed ? ==== */
	while(j-- > 0){
		/* wait */
	}

	/* ==== CS3BCR settings ==== */
	BSC.CS3BCR.LONG = 0x00004400ul;
										/*
											Idle Cycles between Write-read Cycles
											and Write-write Cycles : 0 idle cycles
											Memory type :SDRAM
											Data Bus Size : 16-bit
										*/

	/* ==== CS3WCR settings ==== */
	BSC.CS3WCR.SDRAM.LONG = 0x00002492ul;	
										/*
											Precharge completion wait cycles: 1 cycle
											Wait cycles between ACTV command
											and READ(A)/WRITE(A) command : 1 cycles
											CAS latency for Area 3 : 2 cycles
											Auto-precharge startup wait cycles : 2 cycles
											Idle cycles from REF command/self-refresh
											Release to ACTV/REF/MRS command 
											: 5 cycles
										*/


	/* ==== SDCR settings ==== */
	BSC.SDCR.LONG = 0x00000809ul;
										/* 
											Refresh Control :Refresh 
											RMODE :Auto-refresh is performed 
											BACTV :Auto-precharge mode 
											Row address for Area 3 : 12-bit 
											Column Address for Area 3 : 9-bit 
										*/

	/* ==== RTCOR settings ==== */
	BSC.RTCOR.LONG = 0xa55a0041ul;		/* 
											15.625usec /240nsec 
											= 65(0x41)cycles per refresh  
										*/			



	/* ==== RTCSR settings ==== */
	BSC.RTCSR.LONG = 0xa55a0010ul;	
										/* 
											Initialization sequence start
											Clock select B-phy/16
											Refresh count :Once 
										*/

	/* ==== Written in SDRAM Mode Register ==== */
	SDRAM_MODE = 0;						/*
											The writing data is arbitrary
											SDRAM mode register setting CS3 space
											Burst read (burst length 1)./Burst write
										*/

}

/* End of File */
