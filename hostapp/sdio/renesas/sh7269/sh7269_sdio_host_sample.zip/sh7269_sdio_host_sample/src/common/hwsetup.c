/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : hwsetup.c
*   Abstract    : Hardware initialization function
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "iodefine.h"

/* ==== Prototype declaration ==== */
void  HardwareSetup(void);

/* ==== referenced external Prototype declaration ==== */
extern void io_set_cpg(void);
extern void io_init_port(void);
extern void io_init_bsc_cs0(void);
extern void io_init_sdram(void);
extern void io_init_cache(void);


#pragma section ResetPRG
/******************************************************************************
 * ID          : 
 * Outline     : Hardware initialization function
 * Include     : #include "iodefine.h"
 * Declaration : void  HardwareSetup(void);
 * Description : The initial settings of CPG, PFC, and BSC (Flash memory  
 *             : access control and SDRAM initialization) are processed.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void  HardwareSetup(void)
{

	/*====CPG setting====*/
	io_set_cpg();
	
	/* ==== Port setting==== */
	io_init_port();
	
	/*====CS0 initialization====*/	
	io_init_bsc_cs0();
	
	/*====SDRAM initialization====*/
	io_init_sdram();

	/*====Cache setting====*/
	io_init_cache();

}

/* End of File */
