/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : cache.c
*   Abstract    : sample of cache register
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "iodefine.h"


/* ==== Prototype Declaration ==== */
void io_set_cpg(void);

#pragma section ResetPRG
/*******************************************************************************
 * ID          : 
 * Outline     : CPG settings
 * Include     : #include "iodefine.h"
 * Declaration : void io_set_cpg(void);
 * Description : Clock pulse generator (CPG) is set to set to the internal clock 
 *             : (I Clock), peripheral clocks (P0 & P1 Clock), bus clock (B Clock),  
 *             : and I Clock = 266.67MHz,B Clock = 133.33MHz,P0 Clock = 33.33MHz,
 *             : P1 Clock = 66.67MHz,CKIO = 66.67MHz. 
 *             : This setting example is the case that the function's input clock
 *             : is 13.33MHz.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void io_set_cpg(void)
{


	/* ==== CPG Setting ==== */
	CPG.FRQCR.WORD = 0x1015u;		/* PLL(x20),I:B:P1:P0= 20:10:5:5/2
									* CKIO:Output at time usually,Output when bus right is opened,output at standby"L"
									* Clockin = 13.33MHz, CKIO = 66.67MHz 
									* I Clock = 266.67MHz, B Clock = 133.33MHz, 
									* P1 Clock = 66.67MHz
									* P0 Clock = 33.33MHz
									*/

    /* ---- The clock of all modules is permitted. ---- */
	CPG.STBCR3.BYTE = 0x1Au;		/* Port level is keep in standby mode							*/
									/* IEBus, MTU2,[1],[1], A/D, [1], RTClock    					*/
	CPG.STBCR4.BYTE = 0x00u;		/* SCIF0, SCIF1, SCIF2, SCIF3, SCIF4, SCIF5, SCIF6, SCIF7		*/
	CPG.STBCR5.BYTE = 0x00u;		/* I2C30, I2C31, I2C32, I2C33, RCAN0, RCAN1, RSPI0, RSPI1		*/
	CPG.STBCR6.BYTE = 0x00u;		/* SSI0, SSI1, SSI2, SSI3, CD-ROMDEC, SRC0, SRC1, USB			*/
	CPG.STBCR7.BYTE = 0x32u;		/* SIOF, RSPDIF, [1], [1], VDC4, CMT, [1], NAND					*/
	CPG.STBCR8.BYTE = 0x09u;		/* PWM, MMC, IMRLS, RGPVG, [1], RQSPI0, RQSPI1, [1]				*/
	CPG.STBCR9.BYTE = 0x00u;		/* SDHI00, SDHI01, SDHI10, SDHI11, SSIF4, SSIF5, SSIF6, SSIF7	*/
	CPG.STBCR10.BYTE =0x10u;		/* DVDEC, JCU, DISCOM, [1],SGD0, SGD1, SGD2, SGD3				*/
	
	/* ----  Writing to large-capacity RAM is enabled. ---- */
	CPG.SYSCR5.BYTE = 0x0fu;

}

/* End of File */
