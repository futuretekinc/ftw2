/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : bsc_cs0.c
*   Abstract    : SH7268/SH7269 Initial Settings
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "iodefine.h"


/*  CS0 PAGEMODE setting */
//#define PAGEMODE

/* ==== Prototype Declaration ==== */
void io_init_bsc_cs0(void);

#pragma section ResetPRG
/*******************************************************************************
 * ID          : 
 * Outline     : CS0 setting
 * Include     : #include "iodefine.h"
 * Declaration : void io_init_bsc_cs0(void);
 * Description : Pin function controller (PFC) and bus state controller (BSC) 
 *             : are set, and the access timing to the Flash Memory of CS0 space
 *             : is set.
 *             : The PFC setting is set by bit manipulation not to change the PFC 
 *             : set value which is set by other process.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void io_init_bsc_cs0(void)
{

	/* ==== PFC settings ==== */
	PORT.PFCR3.BIT.PF13MD  = 1u;	/* Set A24 	*/
	PORT.PFCR2.BIT.PF8MD   = 1u;	/* Set A23 	*/
	PORT.PBCR5.BIT.PB22MD  = 1u;	/* Set A22 	*/
	PORT.PBCR5.BIT.PB21MD  = 1u;	/* Set A21 	*/
	PORT.PCCR0.BIT.PC3MD   = 1u;	/* Set WE0# */

#ifdef PAGEMODE

	/* ==== CS0WCR settings ==== */
	BSC.CS0WCR.BROM_ASY.LONG = 0x00020340ul;
									/* Number of Burst: 8 burst x one time 	*/
									/* Number of Burst Wait Cycles: 2 cycles 	*/
									/* Number of Access Wait Cycles: 6 cycles 	*/

	/* ==== CS0BCR settings ==== */
	BSC.CS0BCR.LONG = 0x20001400ul;
									/* Idle Cycles between Write-read Cycles 	*/
									/*  and Write-write Cycles: 2 idle cycles 	*/
									/* Type:Burst ROM (ASY) 					*/
									/* Data Bus Size: 16-bit					*/


#else /* PAGEMODE */

	/* ==== CS0WCR settings ====  */	
	BSC.CS0WCR.NORMAL.LONG = 0x00000ac0ul;
									/* Number of Delay Cycles from Address, 	*/
									/*  CS0# Assertion to RD#,WEn Assertion 	*/
									/*  : 1.5 cycles 				*/
									/* Number of Access Wait Cycles: 5 cycles 	*/
									/* Delay Cycles from RD,WEn# negation to 	*/
									/*  Address,CSn# negation: 0.5 cycles 		*/

	/* ==== CS0BCR settings ==== */
	BSC.CS0BCR.LONG = 0x10000400ul;
									/* Idle Cycles between Write-read Cycles 	*/
									/*  and Write-write Cycles : 1 idle cycle 	*/
									/* Data Bus Size: 16-bit 					*/
#endif /* PAGEMODE */

}

/* End of File */
