/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : vecttbl.c
*   Abstract    : vector table define
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "vect.h"

#pragma section VECTTBL

void (*RESET_Vectors[])(void) = {
//;<<VECTOR DATA START (POWER ON RESET)>>
//;0 Power On Reset PC
    (void*)	PowerON_Reset_PC,                                                                                                                
//;<<VECTOR DATA END (POWER ON RESET)>>
// 1 Power On Reset SP
    __secend("S"),
//;<<VECTOR DATA START (MANUAL RESET)>>
//;2 Manual Reset PC
    (void*)	Manual_Reset_PC,                                                                                                                 
//;<<VECTOR DATA END (MANUAL RESET)>>
// 3 Manual Reset SP
    __secend("S")

};
#pragma section INTTBL
void (*INT_Vectors[])(void) = {
// 4 Illegal code
    INT_Illegal_code,
// 5 Reserved
    Dummy,
// 6 Illegal slot
    INT_Illegal_slot,
// 7 Reserved
    Dummy,
// 8 Reserved
    Dummy,
// 9 CPU Address error
    INT_CPU_Address,
// 10 DMAC Address error
    INT_DMAC_Address,
// 11 NMI
    INT_NMI,
// 12 User breakpoint trap
    INT_User_Break,
// 13 INT_FPU
    INT_FPU,
// 14 H-UDI
    INT_HUDI,
// 15 Bank Overflow
    INT_Bank_Overflow,
// 16 Bank Underflow
    INT_Bank_Underflow,
// 17 Divide by zero
    INT_Divide_by_Zero,
// 18 Divide Overflow
    INT_Divide_Overflow,
// 19 Reserved
    Dummy,
// 20 Reserved
    Dummy,
// 21 Reserved
    Dummy,
// 22 Reserved
    Dummy,
// 23 Reserved
    Dummy,
// 24 Reserved
    Dummy,
// 25 Reserved
    Dummy,
// 26 Reserved
    Dummy,
// 27 Reserved
    Dummy,
// 28 Reserved
    Dummy,
// 29 Reserved
    Dummy,
// 30 Reserved
    Dummy,
// 31 Reserved
    Dummy,
// 32 TRAPA (User Vector)
    INT_TRAPA32,
// 33 TRAPA (User Vector)
    INT_TRAPA33,
// 34 TRAPA (User Vector)
    INT_TRAPA34,
// 35 TRAPA (User Vector)
    INT_TRAPA35,
// 36 TRAPA (User Vector)
    INT_TRAPA36,
// 37 TRAPA (User Vector)
    INT_TRAPA37,
// 38 TRAPA (User Vector)
    INT_TRAPA38,
// 39 TRAPA (User Vector)
    INT_TRAPA39,
// 40 TRAPA (User Vector)
    INT_TRAPA40,
// 41 TRAPA (User Vector)
    INT_TRAPA41,
// 42 TRAPA (User Vector)
    INT_TRAPA42,
// 43 TRAPA (User Vector)
    INT_TRAPA43,
// 44 TRAPA (User Vector)
    INT_TRAPA44,
// 45 TRAPA (User Vector)
    INT_TRAPA45,
// 46 TRAPA (User Vector)
    INT_TRAPA46,
// 47 TRAPA (User Vector)
    INT_TRAPA47,
// 48 TRAPA (User Vector)
    INT_TRAPA48,
// 49 TRAPA (User Vector)
    INT_TRAPA49,
// 50 TRAPA (User Vector)
    INT_TRAPA50,
// 51 TRAPA (User Vector)
    INT_TRAPA51,
// 52 TRAPA (User Vector)
    INT_TRAPA52,
// 53 TRAPA (User Vector)
    INT_TRAPA53,
// 54 TRAPA (User Vector)
    INT_TRAPA54,
// 55 TRAPA (User Vector)
    INT_TRAPA55,
// 56 TRAPA (User Vector)
    INT_TRAPA56,
// 57 TRAPA (User Vector)
    INT_TRAPA57,
// 58 TRAPA (User Vector)
    INT_TRAPA58,
// 59 TRAPA (User Vector)
    INT_TRAPA59,
// 60 TRAPA (User Vector)
    INT_TRAPA60,
// 61 TRAPA (User Vector)
    INT_TRAPA61,
// 62 TRAPA (User Vector)
    INT_TRAPA62,
// 63 TRAPA (User Vector)
    INT_TRAPA63,
// 64 Interrupt IRQ0
    INT_IRQ_IRQ0,
// 65 Interrupt IRQ1
    INT_IRQ_IRQ1,
// 66 Interrupt IRQ2
    INT_IRQ_IRQ2,
// 67 Interrupt IRQ3
    INT_IRQ_IRQ3,
// 68 Interrupt IRQ4
    INT_IRQ_IRQ4,
// 69 Interrupt IRQ5
    INT_IRQ_IRQ5,
// 70 Interrupt IRQ6
    INT_IRQ_IRQ6,
// 71 Interrupt IRQ7
    INT_IRQ_IRQ7,
// 72 Reserved
    Dummy,
// 73 Reserved
    Dummy,
// 74 Reserved
    Dummy,
// 75 Reserved
    Dummy,
// 76 Reserved
    Dummy,
// 77 Reserved
    Dummy,
// 78 Reserved
    Dummy,
// 79 Reserved
    Dummy,
// 80 Interrupt PINT0
    INT_PINT_PINT0,
// 81 Interrupt PINT1
    INT_PINT_PINT1,
// 82 Interrupt PINT2
    INT_PINT_PINT2,
// 83 Interrupt PINT3
    INT_PINT_PINT3,
// 84 Interrupt PINT4
    INT_PINT_PINT4,
// 85 Interrupt PINT5
    INT_PINT_PINT5,
// 86 Interrupt PINT6
    INT_PINT_PINT6,
// 87 Interrupt PINT7
    INT_PINT_PINT7,
// 88 Reserved
    Dummy,
// 89 Reserved
    Dummy,
// 90 Reserved
    Dummy,
// 91 Reserved
    Dummy,
// 92 Reserved
    Dummy,
// 93 Reserved
    Dummy,
// 94 Reserved
    Dummy,
// 95 Reserved
    Dummy,
// 96 Reserved
    Dummy,
// 97 Reserved
    Dummy,
// 98 Reserved
    Dummy,
// 99 Reserved
    Dummy,
// 100 Reserved
    Dummy,
// 101 Reserved
    Dummy,
// 102 Reserved
    Dummy,
// 103 Reserved
    Dummy,
// 104 Reserved
    Dummy,
// 105 Reserved
    Dummy,
// 106 Reserved
    Dummy,
// 107 Reserved
    Dummy,
// 108 DMAC0 DEI0
    INT_DMAC0_DEI0,
// 109 DMAC0 HEI0
    INT_DMAC0_HEI0,
// 110 Reserved
    Dummy,
// 111 Reserved
    Dummy,
// 112 DMAC1 DEI1
    INT_DMAC1_DEI1,
// 113 DMAC1 HEI1
    INT_DMAC1_HEI1,
// 114 Reserved
    Dummy,
// 115 Reserved
    Dummy,
// 116 DMAC2 DEI2
    INT_DMAC2_DEI2,
// 117 DMAC2 HEI2
    INT_DMAC2_HEI2,
// 118 Reserved
    Dummy,
// 119 Reserved
    Dummy,
// 120 DMAC3 DEI3
    INT_DMAC3_DEI3,
// 121 DMAC3 HEI3
    INT_DMAC3_HEI3,
// 122 Reserved
    Dummy,
// 123 Reserved
    Dummy,
// 124 DMAC4 DEI4
    INT_DMAC4_DEI4,
// 125 DMAC4 HEI4
    INT_DMAC4_HEI4,
// 126 Reserved
    Dummy,
// 127 Reserved
    Dummy,
// 128 DMAC5 DEI5
    INT_DMAC5_DEI5,
// 129 DMAC5 HEI5
    INT_DMAC5_HEI5,
// 130 Reserved
    Dummy,
// 131 Reserved
    Dummy,
// 132 DMAC6 DEI6
    INT_DMAC6_DEI6,
// 133 DMAC6 HEI6
    INT_DMAC6_HEI6,
// 134 Reserved
    Dummy,
// 135 Reserved
    Dummy,
// 136 DMAC7 DEI7
    INT_DMAC7_DEI7,
// 137 DMAC7 HEI7
    INT_DMAC7_HEI7,
// 138 Reserved
    Dummy,
// 139 Reserved
    Dummy,
// 140 DMAC8 DEI8
    INT_DMAC8_DEI8,
// 141 DMAC8 HEI8
    INT_DMAC8_HEI8,
// 142 Reserved
    Dummy,
// 143 Reserved
    Dummy,
// 144 DMAC9 DEI9
    INT_DMAC9_DEI9,
// 145 DMAC9 HEI9
    INT_DMAC9_HEI9,
// 146 Reserved
    Dummy,
// 147 Reserved
    Dummy,
// 148 DMAC10 DEI10
    INT_DMAC10_DEI10,
// 149 DMAC10 HEI10
    INT_DMAC10_HEI10,
// 150 Reserved
    Dummy,
// 151 Reserved
    Dummy,
// 152 DMAC11 DEI11
    INT_DMAC11_DEI11,
// 153 DMAC11 HEI11
    INT_DMAC11_HEI11,
// 154 Reserved
    Dummy,
// 155 Reserved
    Dummy,
// 156 DMAC12 DEI12
    INT_DMAC12_DEI12,
// 157 DMAC12 HEI12
    INT_DMAC12_HEI12,
// 158 Reserved
    Dummy,
// 159 Reserved
    Dummy,
// 160 DMAC13 DEI13
    INT_DMAC13_DEI13,
// 161 DMAC13 HEI13
    INT_DMAC13_HEI13,
// 162 Reserved
    Dummy,
// 163 Reserved
    Dummy,
// 164 DMAC14 DEI14
    INT_DMAC14_DEI14,
// 165 DMAC14 HEI14
    INT_DMAC14_HEI14,
// 166 Reserved
    Dummy,
// 167 Reserved
    Dummy,
// 168 DMAC15 DEI15
    INT_DMAC15_DEI15,
// 169 DMAC15 HEI15
    INT_DMAC15_HEI15,
// 170 USB USBI
    INT_USB_USBI,
// 171 VDC4 VI_VSYNC
    INT_VDC4_VI_VSYNC,
// 172 VDC4 VO_VSYNC
    INT_VDC4_VO_VSYNC,
// 173 VDC4 VSYNCERR
    INT_VDC4_VSYNCERR,
// 174 VDC4 VLINE
    INT_VDC4_VLINE,
// 175 VDC4 VFIELD
    INT_VDC4_VFIELD,
// 176 VDC4 VBUFERR1
    INT_VDC4_VBUFERR1,
// 177 VDC4 VBUFERR2
    INT_VDC4_VBUFERR2,
// 178 VDC4 VBUFERR3
    INT_VDC4_VBUFERR3,
// 179 VDC4 VBUFERR4
    INT_VDC4_VBUFERR4,
// 180 IMRLS IMRI
    INT_IMRLS_IMRI,
// 181 JCU JEDI
    INT_JCU_JEDI,
// 182 JCU JDTI
    INT_JCU_JDTI,
// 183 DISC CMPI
    INT_DISC_CMPI,
// 184 RGPVG INT3
    INT_RGPVG_INT3,
// 185 RGPVG INT2
    INT_RGPVG_INT2,
// 186 RGPVG INT1
    INT_RGPVG_INT1,
// 187 RGPVG INT0
    INT_RGPVG_INT0,
// 188 CMT CMT0 CMI0
    INT_CMT0_CMI0,
// 189 CMT CMT1 CMI1
    INT_CMT1_CMI1,
// 190 BSC CMI
    INT_BSC_CMI,
// 191 WDT ITI
    INT_WDT_ITI,
// 192 MTU2 MTU0 TGI0A
    INT_MTU2_TGI0A,
// 193 MTU2 MTU0 TGI0B
    INT_MTU2_TGI0B,
// 194 MTU2 MTU0 TGI0C
    INT_MTU2_TGI0C,
// 195 MTU2 MTU0 TGI0D
    INT_MTU2_TGI0D,
// 196 MTU2 MTU0 TCI0V
    INT_MTU2_TCI0V,
// 197 MTU2 MTU0 TGI0E
    INT_MTU2_TGI0E,
// 198 MTU2 MTU0 TGI0F
    INT_MTU2_TGI0F,
// 199 MTU2 MTU1 TGI1A
    INT_MTU2_TGI1A,
// 200 MTU2 MTU1 TGI1B
    INT_MTU2_TGI1B,
// 201 MTU2 MTU1 TCI1V
    INT_MTU2_TCI1V,
// 202 MTU2 MTU1 TCI1U
    INT_MTU2_TCI1U,
// 203 MTU2 MTU2 TGI2A
    INT_MTU2_TGI2A,
// 204 MTU2 MTU2 TGI2B
    INT_MTU2_TGI2B,
// 205 MTU2 MTU2 TCI2V
    INT_MTU2_TCI2V,
// 206 MTU2 MTU2 TCI2U
    INT_MTU2_TCI2U,
// 207 MTU2 MTU3 TGI3A
    INT_MTU2_TGI3A,
// 208 MTU2 MTU3 TGI3B
    INT_MTU2_TGI3B,
// 209 MTU2 MTU3 TGI3C
    INT_MTU2_TGI3C,
// 210 MTU2 MTU3 TGI3D
    INT_MTU2_TGI3D,
// 211 MTU2 MTU3 TCI3V
    INT_MTU2_TCI3V,
// 212 MTU2 MTU4 TGI4A
    INT_MTU2_TGI4A,
// 213 MTU2 MTU4 TGI4B
    INT_MTU2_TGI4B,
// 214 MTU2 MTU4 TGI4C
    INT_MTU2_TGI4C,
// 215 MTU2 MTU4 TGI4D
    INT_MTU2_TGI4D,
// 216 MTU2 MTU4 TCI4V
    INT_MTU2_TCI4V,
// 217 PWM PWM1
    INT_PWM1,
// 218 PWM PWM2
    INT_PWM2,
// 219 SDG SGD0
    INT_SDG_SGD0,
// 220 SDG SGD1
    INT_SDG_SGD1,
// 221 SDG SGD2
    INT_SDG_SGD2,
// 222 SDG SGD3
    INT_SDG_SGD3,
// 223 A/D ADI
    INT_AD_ADI,
// 224 SSI0 SSIF0
    INT_SSI0_SSIF0,
// 225 SSI0 SSIRXI0
    INT_SSI0_SSIRXI0,
// 226 SSI0 SSITXI0
    INT_SSI0_SSITXI0,
// 227 SSI1 SSII1
    INT_SSI1_SSII1,
// 228 SSI1 SSIRTI1
    INT_SSI1_SSIRTI1,
// 229 SSI2 SSII2
    INT_SSI2_SSII2,
// 230 SSI2 SSIRTI2
    INT_SSI2_SSIRTI2,
// 231 SSI3 SSII3
    INT_SSI3_SSII3,
// 232 SSI3 SSIRTI3
    INT_SSI3_SSIRTI3,
// 233 SSI4 SSII4
    INT_SSI4_SSII4,
// 234 SSI4 SSIRTI4
    INT_SSI4_SSIRTI4,
// 235 SSI5 SSII5
    INT_SSI5_SSII5,
// 236 SSI5 SSIRTI5
    INT_SSI5_SSIRTI5,
// 237 SPDIF SPDIFI
    INT_SPDIF_SPDIFI,
// 238 IIC3 IIC0 STPI0
    INT_IIC3_STPI0,
// 239 IIC3 IIC0 NAKI0
    INT_IIC3_NAKI0,
// 240 IIC3 IIC0 RXI0
    INT_IIC3_RXI0,
// 241 IIC3 IIC0 TXI0
    INT_IIC3_TXI0,
// 242 IIC3 IIC0 TEI0
    INT_IIC3_TEI0,
// 243 IIC3 IIC1 STPI1
    INT_IIC3_STPI1,
// 244 IIC3 IIC1 NAKI1
    INT_IIC3_NAKI1,
// 245 IIC3 IIC1 RXI1
    INT_IIC3_RXI1,
// 246 IIC3 IIC1 TXI1
    INT_IIC3_TXI1,
// 247 IIC3 IIC1 TEI1
    INT_IIC3_TEI1,
// 248 IIC3 IIC2 STPI2
    INT_IIC3_STPI2,
// 249 IIC3 IIC2 NAKI2
    INT_IIC3_NAKI2,
// 250 IIC3 IIC2 RXI2
    INT_IIC3_RXI2,
// 251 IIC3 IIC2 TXI2
    INT_IIC3_TXI2,
// 252 IIC3 IIC2 TEI2
    INT_IIC3_TEI2,
// 253 IIC3 IIC3 STPI3
    INT_IIC3_STPI3,
// 254 IIC3 IIC3 NAKI3
    INT_IIC3_NAKI3,
// 255 IIC3 IIC3 RXI3
    INT_IIC3_RXI3,
// 256 IIC3 IIC3 TXI3
    INT_IIC3_TXI3,
// 257 IIC3 IIC3 TEI3
    INT_IIC3_TEI3,
// 258 SCIF SCIF0 BRI0
    INT_SCIF0_BRI0,
// 259 SCIF SCIF0 ERI0
    INT_SCIF0_ERI0,
// 260 SCIF SCIF0 RXI0
    INT_SCIF0_RXI0,
// 261 SCIF SCIF0 TXI0
    INT_SCIF0_TXI0,
// 262 SCIF SCIF1 BRI1
    INT_SCIF1_BRI1,
// 263 SCIF SCIF1 ERI1
    INT_SCIF1_ERI1,
// 264 SCIF SCIF1 RXI1
    INT_SCIF1_RXI1,
// 265 SCIF SCIF1 TXI1
    INT_SCIF1_TXI1,
// 266 SCIF SCIF2 BRI2
    INT_SCIF2_BRI2,
// 267 SCIF SCIF2 ERI2
    INT_SCIF2_ERI2,
// 268 SCIF SCIF2 RXI2
    INT_SCIF2_RXI2,
// 269 SCIF SCIF2 TXI2
    INT_SCIF2_TXI2,
// 270 SCIF SCIF3 BRI3
    INT_SCIF3_BRI3,
// 271 SCIF SCIF3 ERI3
    INT_SCIF3_ERI3,
// 272 SCIF SCIF3 RXI3
    INT_SCIF3_RXI3,
// 273 SCIF SCIF3 TXI3
    INT_SCIF3_TXI3,
// 274 SCIF SCIF4 BRI4
    INT_SCIF4_BRI4,
// 275 SCIF SCIF4 ERI4
    INT_SCIF4_ERI4,
// 276 SCIF SCIF4 RXI4
    INT_SCIF4_RXI4,
// 277 SCIF SCIF4 TXI4
    INT_SCIF4_TXI4,
// 278 SCIF SCIF5 BRI5
    INT_SCIF5_BRI5,
// 279 SCIF SCIF5 ERI5
    INT_SCIF5_ERI5,
// 280 SCIF SCIF5 RXI5
    INT_SCIF5_RXI5,
// 281 SCIF SCIF5 TXI5
    INT_SCIF5_TXI5,
// 282 SCIF SCIF6 BRI6
    INT_SCIF6_BRI6,
// 283 SCIF SCIF6 ERI6
    INT_SCIF6_ERI6,
// 284 SCIF SCIF6 RXI6
    INT_SCIF6_RXI6,
// 285 SCIF SCIF6 TXI6
    INT_SCIF6_TXI6,
// 286 SCIF SCIF7 BRI7
    INT_SCIF7_BRI7,
// 287 SCIF SCIF7 ERI7
    INT_SCIF7_ERI7,
// 288 SCIF SCIF7 RXI7
    INT_SCIF7_RXI7,
// 289 SCIF SCIF7 TXI7
    INT_SCIF7_TXI7,
// 290 SIOF SIOFI
    INT_SIOF_SIOFI,
// 291 RCAN RCAN0 ERS0
    INT_RCAN0_ERS0,
// 292 RCAN RCAN0 OVR0
    INT_RCAN0_OVR0,
// 293 RCAN RCAN0 RM00
    INT_RCAN0_RM00,
// 294 RCAN RCAN0 RM10
    INT_RCAN0_RM10,
// 295 RCAN RCAN0 SLE0
    INT_RCAN0_SLE0,
// 296 RCAN RCAN1 ERS1
    INT_RCAN1_ERS1,
// 297 RCAN RCAN1 OVR1
    INT_RCAN1_OVR1,
// 298 RCAN RCAN1 RM01
    INT_RCAN1_RM01,
// 299 RCAN RCAN1 RM11
    INT_RCAN1_RM11,
// 300 RCAN RCAN1 SLE1
    INT_RCAN1_SLE1,
// 301 RCAN RCAN2 ERS2
    INT_RCAN2_ERS2,
// 302 RCAN RCAN2 OVR2
    INT_RCAN2_OVR2,
// 303 RCAN RCAN2 RM02
    INT_RCAN2_RM02,
// 304 RCAN RCAN2 RM12
    INT_RCAN2_RM12,
// 305 RCAN RCAN2 SLE2
    INT_RCAN2_SLE2,
// 306 RSPI RSPI0 SPEI0
    INT_RSPI0_SPEI0,
// 307 RSPI RSPI0 SPRI0
    INT_RSPI0_SPRI0,
// 308 RSPI RSPI0 SPTI0
    INT_RSPI0_SPTI0,
// 309 RSPI RSPI1 SPEI1
    INT_RSPI1_SPEI1,
// 310 RSPI RSPI1 SPRI1
    INT_RSPI1_SPRI1,
// 311 RSPI RSPI1 SPTI1
    INT_RSPI1_SPTI1,
// 312 RQSPI RQSPI0 SPEI0
    INT_RQSPI0_SPEI0,
// 313 RQSPI RQSPI0 SPRI0
    INT_RQSPI0_SPRI0,
// 314 RQSPI RQSPI0 SPTI0
    INT_RQSPI0_SPTI0,
// 315 RQSPI RQSPI1 SPEI1
    INT_RQSPI1_SPEI1,
// 316 RQSPI RQSPI1 SPRI1
    INT_RQSPI1_SPRI1,
// 317 RQSPI RQSPI1 SPTI1
    INT_RQSPI1_SPTI1,
// 318 IEB IEB
    INT_IEB_IEB,
// 319 ROMDEC ISY
    INT_ROMDEC_ISY,
// 320 ROMDEC IERR
    INT_ROMDEC_IERR,
// 321 ROMDEC ITARG
    INT_ROMDEC_ITARG,
// 322 ROMDEC ISEC
    INT_ROMDEC_ISEC,
// 323 ROMDEC IBUF
    INT_ROMDEC_IBUF,
// 324 ROMDEC IREADY
    INT_ROMDEC_IREADY,
// 325 FLCTL FLSTEI
    INT_FLCTL_FLSTEI,
// 326 FLCTL FLTENDI
    INT_FLCTL_FLTENDI,
// 327 FLCTL FLTREQ0I
    INT_FLCTL_FLTREQ0I,
// 328 FLCTL FLTREQ1I
    INT_FLCTL_FLTREQ1I,
// 329 MMC MMC0
    INT_MMC_MMC0,
// 330 MMC MMC1
    INT_MMC_MMC1,
// 331 MMC MMC2
    INT_MMC_MMC2,
// 332 SDHI SDHI0 SDHI0_3
    INT_SDHI0_SDHI0_3,
// 333 SDHI SDHI0 SDHI0_0
    INT_SDHI0_SDHI0_0,
// 334 SDHI SDHI0 SDHI0_1
    INT_SDHI0_SDHI0_1,
// 335 SDHI SDHI1 SDHI1_3
    INT_SDHI1_SDHI1_3,
// 336 SDHI SDHI1 SDHI1_0
    INT_SDHI1_SDHI1_0,
// 337 SDHI SDHI1 SDHI1_1
    INT_SDHI1_SDHI1_1,
// 338 RTC ARM
    INT_RTC_ARM,
// 339 RTC PRD
    INT_RTC_PRD,
// 340 RTC CUP
    INT_RTC_CUP,
// 341 SRC SRC0 OVF0
    INT_SRC0_OVF0,
// 342 SRC SRC0 UDF0
    INT_SRC0_UDF0,
// 343 SRC SRC0 CEF0
    INT_SRC0_CEF0,
// 344 SRC SRC0 ODFI0
    INT_SRC0_ODFI0,
// 345 SRC SRC0 IDEI0
    INT_SRC0_IDEI0,
// 346 SRC SRC1 OVF1
    INT_SRC1_OVF1,
// 347 SRC SRC1 UDF1
    INT_SRC1_UDF1,
// 348 SRC SRC1 CEF1
    INT_SRC1_CEF1,
// 349 SRC SRC1 ODFI1
    INT_SRC1_ODFI1,
// 350 SRC SRC1 IDEI1
    INT_SRC1_IDEI1,
// 351 SRC SRC2 OVF2
    INT_SRC2_OVF2,
// 352 SRC SRC2 UDF2
    INT_SRC2_UDF2,
// 353 SRC SRC2 CEF2
    INT_SRC2_CEF2,
// 354 SRC SRC2 ODFI2
    INT_SRC2_ODFI2,
// 355 SRC SRC2 IDEI2
    INT_SRC2_IDEI2,
};

/* End of File */