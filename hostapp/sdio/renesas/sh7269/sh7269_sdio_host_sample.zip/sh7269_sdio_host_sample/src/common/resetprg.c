/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : resetprg.c
*   Abstract    : Reset Program
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include <machine.h>
#include <_h_c_lib.h>
#include "stacksct.h"
#include "iodefine.h"

#define FPSCR_Init    0x00040001

#define SR_Init    0x000000F0
#define INT_OFFSET 0x10

extern unsigned int INT_Vectors;
void PowerON_Reset_PC(void);
void Manual_Reset_PC(void);

extern void main(void);
extern void HardwareSetup(void);
extern void io_cache_writeback(void);
extern void _INIT_IOLIB(void);



//extern void srand(unsigned int);	// Remove the comment when you use rand()
//extern char *_s1ptr;			// Remove the comment when you use strtok()		

/*==== Switch section name to ResetPRG ====*/
#pragma section ResetPRG

/*==== Specify the entry function ====*/
#pragma entry PowerON_Reset_PC

/*******************************************************************************
 * ID          : 
 * Outline     : CPU initialization function
 * Include     : #include "iodefine.h"
 * Declaration : void PowerON_Reset_PC(void) ;
 * Description : It is the CPU initialization process to register the power on 
 *             : reset exception vector table.
 *             : This function is firstly executed after power on reset.
 *             : Enable the processes that are commented depending on its needs.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void PowerON_Reset_PC(void)
{ 	
	set_fpscr(FPSCR_Init);

	/*==== HardwareSetup function====*/	 
	HardwareSetup();	// Use Hardware Setup
		
	/*==== B and D sections initialization ====*/ 
	_INITSCT();
	io_cache_writeback();

	/*==== Vector base register (VBR) setting ====*/
	set_vbr((void *)((char *)&INT_Vectors - INT_OFFSET));
	
	_INIT_IOLIB();				// Use stdio I/O

//	errno=0;					// Remove the comment when you use errno
//	srand(1);					// Remove the comment when you use rand()
//	_s1ptr=NULL;				// Remove the comment when you use strtok()

	/*==== Status register setting ====*/ 
	set_cr(SR_Init);
	nop();

	/* ==== Bank number register setting ==== */
	INTC.IBNR.BIT.BE = 0x01;	/* Use the register bank in all interrupts */
	
	/* ==== Interrupt mask level change ==== */
	set_imask(0);

	/*==== Function call of main function ====*/ 	
	main();
	
	/*==== sleep instruction execution ====*/ 
	sleep();
}

/*******************************************************************************
 * ID          : 
 * Outline     : Manual reset process
 * Include     : 
 * Declaration : void Manual_Reset_PC(void);
 * Description : It is the function to register the manual reset exception vector table.
 *             : The process is not defined in the reference program.
 *             : Add the processes depending on its needs
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void Manual_Reset_PC(void)	
{
	/* NOP */
}
/* END of File */
