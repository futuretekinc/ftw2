/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : lowsrc.c
*   Abstract    : Standard I/O files interface
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include <string.h> 
#include <stdio.h>
#include <stddef.h>
#include "lowsrc.h"

/* file number */

#define STDIN  0                       /* Standard input (console)        */
#define STDOUT 1                       /* Standard output (console)       */
#define STDERR 2                       /* Standard error output (console) */

#define FLMIN  0                       /* Minimum file number             */
#define FLMAX  3                       /* Maximum number of files         */

/* file flag */

#define O_RDONLY 0x0001                /* Read only                       */
#define O_WRONLY 0x0002                /* Write only                      */
#define O_RDWR   0x0004                /* Both read and write             */

/* special character code */

#define CR 0x0d                        /* Carriage return                 */
#define LF 0x0a                        /* Line feed                       */

/* stream buffer size */
#define BUFF_SIZE	256

const int _nfiles = IOSTREAM;
struct _iobuf _iob[IOSTREAM];
unsigned char sml_buf[IOSTREAM];
static char io_buff[IOSTREAM][BUFF_SIZE];

/**************************************************************************/
/* Declaration of reference function                                      */
/* Reference of assembly program in which the simulator debugger input or */
/* output characters to the console                                       */
/**************************************************************************/
extern void charput(char);              /* One character input            */
extern char charget(void);              /* One character oputput          */
extern int sio_write(int file_no , const char *buffer , unsigned int n);
extern int sio_read(int file_no , char *buffer , unsigned int n);
extern void io_init_scif2(void);

/**************************************************************************/
/* Definition of static variable:                                         */
/* Definition of static variables used in low-level interface routines    */
/**************************************************************************/

static int flmod[FLMAX];                   /* Open file mode specification area */

/**************************************************************************/
/*       open:file open                                                   */
/*          Return value:File number (Pass)                               */
/*                       -1          (Failure)                            */
/**************************************************************************/
int open(char *name,int mode,int flg)
{
	int ret;
	int tmp;

	tmp = flg;

	/* Check mode depending on file name and return file numbers          */

	if(strcmp(name,"stdin")==0){		/* Standard input file	 	  */
		if((mode&O_RDONLY)==0){
			return -1;
		}
		flmod[STDIN]=mode;
		ret = STDIN;
	}
	else if(strcmp(name,"stdout")==0){	/* Standard output file          */
		if((mode&O_WRONLY)==0){
			return -1;
		}
		flmod[STDOUT]=mode;
		ret = STDOUT;
	}
	else if (strcmp(name,"stderr")==0){	/* Standard error file           */
		if((mode&O_WRONLY)==0){
			return -1;
		}
		flmod[STDERR]=mode;
		ret = STDERR;
	}
	else{
		ret = -1;						/* Error			  */
	}
	
	return ret;
}

/**************************************************************************/
/*   close:File close                                                     */
/*     Return value:0 (pass)                                              */
/*                  -1 (Failure)                                          */
/**************************************************************************/
int close(int fileno)                      /* File number		  */
{
	/* File number range check     */
	if(fileno<FLMIN || FLMAX<fileno){
		return -1;
	}
	
	flmod[fileno]=0;			   /* File mode reset		  */
	return 0;
}

/**************************************************************************/
/* read:Data read                                                         */
/*  Return value:Number of read characters (Pass)                         */
/*               -1                        (Failure)                      */
/**************************************************************************/
int read(int  fileno,char *buf,unsigned int count)
{
	static int buff_num = 0;
	static int read_pos = 0;
	int i;
	
	if(fileno == STDIN){
		if(buff_num == 0){
			buff_num = sio_read(fileno, io_buff[0], BUFF_SIZE);
			read_pos = 0;
		}
	
		if(buff_num > 0){
			for(i=0; (i < count) && (buff_num > 0) ; i++,buff_num--){
				*buf++ = io_buff[0][read_pos++];
			}
			return i;
		}
	}

	return -1;
}

/**************************************************************************/
/* write:Data write                                                       */
/*	Return value:Number of write characters (Pass)                        */
/*	             -1                         (Failure)                     */
/**************************************************************************/
int write(int  fileno, char *buf, unsigned int  count)
{
	
	if(fileno == STDOUT || fileno == STDERR){
		return sio_write(fileno,buf,count);
	}
	
	return -1;
}

/**************************************************************************/
/* lseek:Definition of file read/write position                           */
/*	Return value:Offset from the top of file read/whrte position(Pass)    */
/*	             -1              (Failure)                                */
/*	(lseek is not supported in the console input/output)                  */
/**************************************************************************/
long lseek(int  fileno,long offset,int  base)
{
	int  tmp_fileno;
	long tmp_offset;
	int  tmp_base;
	
	tmp_fileno = fileno;
	tmp_offset = offset;
	tmp_base = base;

     return -1;
}


/****************************************************************************/
/* _INIT_IOLIB                                                              */
/*	Initialize C library Functions, if necessary.                           */
/****************************************************************************/
void _INIT_IOLIB(void)
{
	FILE *fp;
	int i;

	for( fp = _iob; fp < _iob + _nfiles; fp++ ){
		fp->_bufptr = NULL;
		fp->_bufcnt = 0;
		fp->_buflen = 0;
		fp->_bufbase = NULL;
		fp->_ioflag1 = 0;
		fp->_ioflag2 = 0;
		fp->_iofd = 0;
	 }

	if(freopen( "stdin", "r", stdin )==NULL){
		stdin->_ioflag1 = 0xff;
	}
	stdin->_ioflag1 |= _IOUNBUF;

	if(freopen( "stdout", "w", stdout )==NULL){
		stdout->_ioflag1 = 0xff;
	}
	stdout->_ioflag1 |= _IOUNBUF;

	if(freopen( "stderr", "w", stderr )==NULL){
		stderr->_ioflag1 = 0xff;
	}
	stderr->_ioflag1 |= _IOUNBUF;

	for( i=1; i < _nfiles; i++ ){
		/* io_buff[0] for stdin used local buffing */
		setvbuf(&_iob[i],io_buff[i],_IOLBF,BUFF_SIZE);
	}
	
	/* SCIF initial for console */
	io_init_scif2();		/* Set the bit rate to 115200bps */

}

/****************************************************************************/
/* _CLOSEALL                                                                */
/****************************************************************************/

void _CLOSEALL(void)
{
	int i;

	for( i=0; i < _nfiles; i++ ){
		if( _iob[i]._ioflag1 & (_IOREAD | _IOWRITE | _IORW ) ){
			fclose( & _iob[i] );
		}
	}
}

/* End of File */
