/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : dbsct.c
*   Abstract    : section table
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "typedefine.h"

#pragma section $DSEC
static const struct {
    _UBYTE *rom_s;       /* start address of ROM */
    _UBYTE *rom_e;       /* end   address of ROM */
    _UBYTE *ram_s;       /* start address of RAM */
}DTBL[]={
    { __sectop("D"), __secend("D"), __sectop("R") },
    { __sectop("DINTTBL"), __secend("DINTTBL"), __sectop("RINTTBL") },
};
#pragma section $BSEC
static const struct {
    _UBYTE *b_s;         /* start address */
    _UBYTE *b_e;         /* end   address */
}BTBL[] ={
    { __sectop("B"), __secend("B") }
};

/* End of File */