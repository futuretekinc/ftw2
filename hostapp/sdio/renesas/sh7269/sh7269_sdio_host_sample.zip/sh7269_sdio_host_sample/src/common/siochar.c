/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : siochar.c
*   Abstract    : sio interface getchar / putchar
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "iodefine.h"

/* ====  Prototype function ==== */
void io_init_scif2(void);
char io_getchar(void);
void io_putchar(char c);

#if 0

/*******************************************************************************
 * ID          : 
 * Outline     : Initialize SCFI2
 * Include     : 
 * Declaration : void io_init_scif2(void);
 * Description : This function initializes SCIF channel 2 as UART mode.
 *             : The transmit and the receive of SCIF channel 2 are enabled.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void io_init_scif2(void)
{

	/* ==== SCIF2 initial setting ==== */
	/* ---- Serial control register (SCSCRi) setting ---- */
	SCIF2.SCSCR.WORD = 0x0000;	/* SCIF2 transmitting and receiving operations stop */

	/* ---- FIFO control register (SCFCRi) setting ---- */
	SCIF2.SCFCR.BIT.TFRST = 1;	/* Transmit FIFO reset */

	/* ---- FIFO control register (SCFCRi) setting ---- */
	SCIF2.SCFCR.BIT.RFRST = 1;	/* Receive FIFO data register reset */

	/* ---- Serial status register(SCFSRi) setting ---- */
	SCIF2.SCFSR.WORD &= 0xff6e;	/* ER,BRK,DR bit clear */

	/* ---- Line status register (SCLSRi) setting ---- */
	SCIF2.SCLSR.BIT.ORER = 0;	/* ORER bit clear */

	/* ---- Serial control register (SCSCRi) setting ---- */
	SCIF2.SCSCR.BIT.CKE = 0x0;	/* B'00 : Internal CLK */

	/* ---- Serial mode register (SCSMRi) setting ---- */
	SCIF2.SCSMR.WORD = 0x0000;
								/*	Communication mode 	0: Asynchronous mode	      */
								/*	Character length   	0: 8-bit data			      */
								/*	Parity enable      	0: Add and check are disabled */
								/*	Stop bit length   	0: 1 stop bit 				  */
								/*	Clock select       	0: Table value 			      */

	/* ---- Bit rate register (SCBRRi) setting ---- */
	SCIF2.SCBRR.BYTE 	= 17;	/* 115200bps   error 0.46% */


	/* ---- FIFO control register (SCFCRi) setting ---- */
	SCIF2.SCFCR.WORD = 0x0030;	
								/* RTS output active trigger        :Initial value */
								/* Receive FIFO data trigger        :14-data       */
								/* Modem control enable             :Disabled      */
								/* Receive FIFO data register reset :Disabled      */
								/* Loop-back test                   :Disabled      */

	/* ---- Serial port register (SCSPTRi) setting ---- */
	SCIF2.SCSPTR.WORD |= 0x0003;	/* Serial port  break output(SPB2IO)  1: Enabled */
									/* Serial port break data(SPB2DT)  1: High-level */

	/* ==== Pin function controller (PFC) setting ==== */
	PORT.PFCR4.WORD = 0x5a04;	/* Switch to TxD2 pin */

	/* ==== Pin function controller (PFC) setting ==== */
	PORT.PFCR3.BIT.PF14MD = 0x4;	/* Switch to RxD2 pin */

	/* ---- Serial control register (SCSCRi) setting ---- */
	SCIF2.SCSCR.WORD = 0x0030;
							/* SCIF2 transmitting and receiving operations are enabled */

}

/*******************************************************************************
 * ID          : 
 * Outline     : Obtaining character
 * Include     : 
 * Declaration : char io_getchar(void) ;
 * Description : One character is received from SCIF2, and it's data is returned.
 *             : This function keeps waiting until it can obtain the receiving data.
 * Argument    : void
 * Return Value: Character to receive (Byte).
 * Note        : None
*******************************************************************************/
char io_getchar(void)
{
	char data;

	/* Confirming receive error(ER,DR,BRK) */
	if (SCIF2.SCFSR.WORD & 0x09c) {
		/* Detect receive error */
		SCIF2.SCSCR.BIT.RE = 0;		/* Disable reception */
		SCIF2.SCFCR.BIT.RFRST = 1;	/* Reset receiving FIFO */
		SCIF2.SCFCR.BIT.RFRST = 0;	/* Clearing FIFO reception reset */
		SCIF2.SCFSR.WORD &= ~0x9c;	/* Error bit clear */
		SCIF2.SCSCR.BIT.RE = 1;		/* Enable reception */
		return 0;
	}

	/* Is there receive FIFO data? */
	while(SCIF2.SCFSR.BIT.RDF == 0){
		/* WAIT */
	}

	/* Read receive data */
	data = SCIF2.SCFRDR.BYTE;
	/* Clear RDF */
	SCIF2.SCFSR.BIT.RDF = 0;

	/* Is it overflowed? */
	if(SCIF2.SCLSR.BIT.ORER == 1){
		SCIF2.SCLSR.BIT.ORER = 0;		/* ORER clear */
	}

	return data;

}

/*******************************************************************************
 * ID          : 
 * Outline     : Character output
 * Include     : 
 * Declaration : void io_putchar(char c);
 * Description : Character c is output to SCIF2.
 *             : This function keeps waiting until it becomes the transmission
 *             : enabled state.
 * Argument    : char c : character to output
 * Return Value: void
 * Note         : None
*******************************************************************************/
void io_putchar(char c)
{
	/* Check if it is possible to transmit (TDFE flag) */
	while(SCIF2.SCFSR.BIT.TDFE == 0){
		/* Wait */
	}

	/* Write the receiving data in TDR */
	SCIF2.SCFTDR.BYTE = c;

	/* Clear TDRE and TEND flag */
	SCIF2.SCFSR.WORD &= ~0x0060 ;

}

#else

/*******************************************************************************
 * Declaration : void io_init_SCIF1(void);
 * Description : This function initializes SCIF channel 2 as UART mode.
 *             : The transmit and the receive of SCIF channel 2 are enabled.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void io_init_scif2(void)
{	/* ==== SCIF1 initial setting ==== */
	/* ---- Serial control register (SCSCRi) setting ---- */
	SCIF1.SCSCR.WORD = 0x0000;	/* SCIF1 transmitting and receiving operations stop */

	/* ---- FIFO control register (SCFCRi) setting ---- */
	SCIF1.SCFCR.BIT.TFRST = 1;	/* Transmit FIFO reset */

	/* ---- FIFO control register (SCFCRi) setting ---- */
	SCIF1.SCFCR.BIT.RFRST = 1;	/* Receive FIFO data register reset */

	/* ---- Serial status register(SCFSRi) setting ---- */
	SCIF1.SCFSR.WORD &= 0xff6e;	/* ER,BRK,DR bit clear */

	/* ---- Line status register (SCLSRi) setting ---- */
	SCIF1.SCLSR.BIT.ORER = 0;	/* ORER bit clear */

	/* ---- Serial control register (SCSCRi) setting ---- */
	SCIF1.SCSCR.BIT.CKE = 0x0;	/* B'00 : Internal CLK */

	/* ---- Serial mode register (SCSMRi) setting ---- */
	SCIF1.SCSMR.WORD = 0x0000;
								/*	Communication mode 	0: Asynchronous mode	      */
								/*	Character length   	0: 8-bit data			      */
								/*	Parity enable      	0: Add and check are disabled */
								/*	Stop bit length   	0: 1 stop bit 				  */
								/*	Clock select       	0: Table value 			      */

	/* ---- Bit rate register (SCBRRi) setting ---- */
	SCIF1.SCBRR.BYTE 	= 17;	/* 115200bps   error 0.46% */

	/* ---- FIFO control register (SCFCRi) setting ---- */
	SCIF1.SCFCR.WORD = 0x0030;	
								/* RTS output active trigger        :Initial value */
								/* Receive FIFO data trigger        :14-data       */
								/* Modem control enable             :Disabled      */
								/* Receive FIFO data register reset :Disabled      */
								/* Loop-back test                   :Disabled      */

	/* ---- Serial port register (SCSPTRi) setting ---- */
	SCIF1.SCSPTR.WORD |= 0x0003;	/* Serial port  break output(SPB2IO)  1: Enabled */
									/* Serial port break data(SPB2DT)  1: High-level */

	/* ==== Pin function controller (PFC) setting ==== */
//+	PORT.PFCR4.WORD = 0x5a04;	/* Switch to TxD2 pin */
	//PORT.PJCR6.BIT.PJ26MD= 0x5;	/* Switch to TxD1 pin */	//+
	PORT.PFCR2.BIT.PF11MD= 0x4;	/* Switch to TxD1 pin */	//+
	/* ==== Pin function controller (PFC) setting ==== */
//+	PORT.PFCR3.BIT.PF14MD = 0x4;	/* Switch to RxD2 pin */
	//PORT.PJCR6.BIT.PJ25MD = 0x5;	/* Switch to RxD1 pin */	//+
	PORT.PFCR3.BIT.PF12MD = 0x4;	/* Switch to RxD1 pin */	//+
	
	/* ---- Serial control register (SCSCRi) setting ---- */
	SCIF1.SCSCR.WORD = 0x0030;
							/* SCIF1 transmitting and receiving operations are enabled */

}
/*******************************************************************************
 * ID          : 
 * Outline     : Obtaining character
 * Include     : 
 * Declaration : char io_getchar(void) ;
 * Description : One character is received from SCIF1, and it's data is returned.
 *             : This function keeps waiting until it can obtain the receiving data.
 * Argument    : void
 * Return Value: Character to receive (Byte).
 * Note        : None
*******************************************************************************/
char io_getchar(void)
{
	char data;

	/* Confirming receive error(ER,DR,BRK) */
	if (SCIF1.SCFSR.WORD & 0x09c) {
		/* Detect receive error */
		SCIF1.SCSCR.BIT.RE = 0;		/* Disable reception */
		SCIF1.SCFCR.BIT.RFRST = 1;	/* Reset receiving FIFO */
		SCIF1.SCFCR.BIT.RFRST = 0;	/* Clearing FIFO reception reset */
		SCIF1.SCFSR.WORD &= ~0x9c;	/* Error bit clear */
		SCIF1.SCSCR.BIT.RE = 1;		/* Enable reception */
		return 0;
	}

	/* Is there receive FIFO data? */
	while(SCIF1.SCFSR.BIT.RDF == 0){
		/* WAIT */
	}

	/* Read receive data */
	data = SCIF1.SCFRDR.BYTE;
	/* Clear RDF */
	SCIF1.SCFSR.BIT.RDF = 0;

	/* Is it overflowed? */
	if(SCIF1.SCLSR.BIT.ORER == 1){
		SCIF1.SCLSR.BIT.ORER = 0;		/* ORER clear */
	}

	return data;

}

char io_getcharNonBlock(void)
{
	char data;
    int i=0;
	/* Confirming receive error(ER,DR,BRK) */
	if (SCIF1.SCFSR.WORD & 0x09c) {
		/* Detect receive error */
		SCIF1.SCSCR.BIT.RE = 0;		/* Disable reception */
		SCIF1.SCFCR.BIT.RFRST = 1;	/* Reset receiving FIFO */
		SCIF1.SCFCR.BIT.RFRST = 0;	/* Clearing FIFO reception reset */
		SCIF1.SCFSR.WORD &= ~0x9c;	/* Error bit clear */
		SCIF1.SCSCR.BIT.RE = 1;		/* Enable reception */
		return 0;
	}

	/* Is there receive FIFO data? */
	while(SCIF1.SCFSR.BIT.RDF == 0){
		/* wait for a small time then return */
		for(i=0;i<1000;i++);
		if(SCIF1.SCFSR.BIT.RDF == 0)
		{
		   return 0;
		}
		else
		{
		   break;
		}
	}

	/* Read receive data */
	data = SCIF1.SCFRDR.BYTE;
	/* Clear RDF */
	SCIF1.SCFSR.BIT.RDF = 0;

	/* Is it overflowed? */
	if(SCIF1.SCLSR.BIT.ORER == 1){
		SCIF1.SCLSR.BIT.ORER = 0;		/* ORER clear */
	}

	return data;

}


/*******************************************************************************
 * ID          : 
 * Outline     : Character output
 * Include     : 
 * Declaration : void io_putchar(char c);
 * Description : Character c is output to SCIF1.
 *             : This function keeps waiting until it becomes the transmission
 *             : enabled state.
 * Argument    : char c : character to output
 * Return Value: void
 * Note         : None
*******************************************************************************/
void io_putchar(char c)
{
	/* Check if it is possible to transmit (TDFE flag) */
	while(SCIF1.SCFSR.BIT.TDFE == 0){
		/* Wait */
	}

	/* Write the receiving data in TDR */
	SCIF1.SCFTDR.BYTE = c; 

	/* Clear TDRE and TEND flag */
	SCIF1.SCFSR.WORD &= ~0x0060 ;

}

#endif

/* End of File */