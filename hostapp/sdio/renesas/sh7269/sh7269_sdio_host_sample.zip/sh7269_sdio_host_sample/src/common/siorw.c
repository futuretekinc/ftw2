/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : siorw.c
*   Abstract    : read/write function for SCIF
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include <stdio.h>

/* ====  Prototype function ==== */
extern char io_getchar(void);
extern void io_putchar(char c);

int sio_write(int file_no , const char *buffer , unsigned int n);
int sio_read(int file_no , char *buffer , unsigned int n);

/* File descriptor */
#define	STDIN	0
#define	STDOUT	1
#define	STDERR	2


/*******************************************************************************
 * ID          : 
 * Outline     : write function for serial
 * Include     : 
 * Declaration : int sio_write(int file_no, char *buffer, unsigned int n);
 * Description : The character strings specified with buffer is output for n 
 *             : bytes from serial port. The output is determined by file number fileno.
 *             : The effective outputs in this version are STDOUT and STDERR, and
 *             : it is output to the same serial port.
 *             : The linefeed code '\n'(LF) is converted in '\r'(CR)+'\n'(LF) to output.
 * Argument    : int file_no; I : File number to be the target of writing
 *             : char *buffer; O : Pointer to the area in which writing data is stored 
 *             : unsigned int n; I : Writing bytes
 * Return Value: >=0 : Number of transmitting characters
 *             : -1  : File number error
 * Note         : None
*******************************************************************************/
int sio_write(int file_no , const char *buffer , unsigned int n)
{
	 int i;

	if( file_no == STDOUT || file_no == STDERR){
		for( i = 0; i < n; i++ ){
			/* Writing in buffer converting linefeed code */
			if( *(buffer+i) == '\n'){
				if( i == 0 ){
					io_putchar( '\r' );
				}
				else{
					if( *(buffer+i-1) != '\r' )
						io_putchar( '\r' );
				}
				io_putchar( '\n' );
			}
			else{
				io_putchar( *(buffer+i) );
			}
		}
		return i;

	}
	return -1;	//File number error
}

/*******************************************************************************
 * ID          : 
 * Outline     : read function for serial  
 * Include     : 
 * Declaration : int sio_read(int file_no , char *buffer , unsigned int n);
 * Description : The character strings specified with buffer is input for 
 *             : n bytes from serial port.The input is determined by file number fileno.
 *             : The effective input in this version is STDIN.
 *             : 
 *             : The linefeed code '\r'(CR)+'\n'(LF) is converted in '\n'(LF) to input.
 * Argument    : int file_no; I : File number to be the target of reading
 *             : char *buffer; O : Pointer to the area in which reading data is stored 
 *             : unsigned int n; I : Reading bytes
 * Return Value: >0  : Number of receiving characters
 *             : -1  : File number, receiving data error
 * Note         : None
*******************************************************************************/
int sio_read(int file_no , char *buffer , unsigned int n)
{
	unsigned char cc, SP_char;
	int i;
	static int sjis_flg=0;

	if( file_no == STDIN ){

		for( i = 0; i < n; ){

			/* Reading receiving data */
			cc = io_getchar();

			if( cc == 0xff ){/* -1 is returned when it is receiving data error */
				return -1;
			}
			
			if(sjis_flg == 1){
				sjis_flg = 0;
				sio_write(STDOUT, (char *)&cc, 1);
				*(buffer+i) = cc;
				i++;
				
			}
			else if( 0x20 <= cc && cc <= 0x7E ){
				/* Data possible to display */
				sio_write(STDOUT, (char *)&cc, 1);
				*(buffer+i) = cc;
				i++;
			}
			else if( cc == '\b' ){		/* BS process */
				if( i > 0 ){
					SP_char = 0x20;
					sio_write(STDOUT, (char *)&cc, 1);
					sio_write(STDOUT, (char *)&SP_char, 1);
					sio_write(STDOUT, (char *)&cc, 1);
					i--;
				}
			}
			else if( cc == '\r' ){		/* CR process */
				*(buffer+i) = '\n';
				sio_write(STDOUT, buffer+i, 1);
				i++;
				break;
			}
			/* Japanese SJIS ?*/
			else if( (cc >= 0x80 && cc < 0xa0) || (cc >= 0xe0 && cc < 0xfe)) {
				/* Data possible to display  */
				sio_write(STDOUT, (char *)&cc, 1);
				*(buffer+i) = cc;
				i++;
				sjis_flg=1;
			}
		}
		return i;
	}
	return -1;		//File number error
}

/* End of File */
