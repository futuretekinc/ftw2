/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : cache.c
*   Abstract    : sample of cache register
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include <machine.h>
#include "iodefine.h"


/* ==== Prototype Declaration ==== */
void io_init_cache(void);
int io_cache_writeback(void);


#pragma section CACHE		/* It is placed in the CS0 cache-disabled space */ 
/*******************************************************************************
 * ID          : 
 * Outline     : Cache initialization
 * Include     : #include "iodefine.h"
 * Declaration : void io_init_cache(void);
 * Description : Instruction/operand cache are flushed and enabled.
 *             : The section name of this function is changed to be placed in 
 *             : the cache-disabled.
 *             : When this function is used only in the state of interrupt level 15,
 *             : the setting and clearing of interrupt mask need not be processed.
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void io_init_cache(void)
{ 
	volatile unsigned long reg;
	int mask;

	/* ==== Interrupt mask setting ==== */
	mask = get_imask();
	set_imask(15);					/* Set to the level 15 */

	/* ==== Cache register setting ==== */
	CCNT.CCR1.LONG = 0x0909ul;	/* Write back ON */
	
									/* 
										ICF=1:Instruction cache flushed
										ICE=1:Instruction cache enabled
										OCF=1:Operand cache flushed
										OCE=1:Operand cache enabled
									*/
	/* ==== Reading cache register ==== */
	reg = CCNT.CCR1.LONG ;

	/* ==== Clearing interrupt mask ==== */
	set_imask(mask);					/* Set to the original level */

}

/*******************************************************************************
 * ID          : 
 * Outline     : Write-back of cache
 * Include     : #include "iodefine.h"
 * Declaration : int io_cache_writeback(void);
 * Description : All lines of operand cache are disabled, and the contents of 
 *             : cache memory are written back to the external memory.
 *             : It has nothing to do with the write-through mode.
 * Argument    : void
 * Return Value: 0 : Normal completion
 * Note        : None
*******************************************************************************/
int io_cache_writeback(void)
{ 
	volatile unsigned long *arry;
	unsigned int i,j;
	int mask;

	/* ==== Interrupt mask setting ==== */
	mask = get_imask();
	set_imask(15);					/* Set to the level 15 */
	
	/* ====  All entries disabled ==== */
	for(i=0u; i <4u; i++){
		for(j=0u; j < 128u; j++){
			/* ---- Creating an address array address ---- */
			arry = (volatile unsigned long *)(0xf0800000 | (i<<11) | (j<<4));
			/* ---- Write U=0 and V=0 in the address array ---- */
			*arry &= 0xfffffffcul;		/* V=0,U=0 */
		}
	}
	
	/* ==== Interrupt mask recovery ==== */
	set_imask(mask);				/* Set to the original level */
	
	return 0;
}


/* End of File */
