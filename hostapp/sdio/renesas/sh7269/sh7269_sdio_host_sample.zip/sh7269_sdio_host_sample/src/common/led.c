/*******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corporation and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corporation and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
* Copyright (C) 2011 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7268/SH7269 Sample Program
*   File Name   : led.c
*   Abstract    : LED port test
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.07.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.03 Release02).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : Sep.16,2011 Ver.1.00.00 First Release
*******************************************************************************/
#include "iodefine.h"
#include "r0k57269.h"



/*******************************************************************************
 * ID         : 
 * Outline    : The port for LED is initialized
 * Include    : #include "iodefine.h" 
 * Declaration: void led_init(void);
 * Function   : The port for LED is initialized
 * Argument   : void
 * ReturnValue: void
 * Notice     : 
 * Note       : None
*******************************************************************************/
void led_init(void)
{

	/* ---- High ---- */			/* LED All Off	*/
	PORT.PJDR1.BYTE.L = 0x0c;

	/* ---- Output ---- */
	PORT.PJIOR1.BIT.PJ18IOR = 1;	/* PJ18 */
	PORT.PJIOR1.BIT.PJ19IOR = 1;	/* PJ19 */

}

/*******************************************************************************
 * ID          : 
 * Outline     : Lighting
 * Include     : #include "iodefine.h"
 * Declaration : void led_on(unsigned short ledno);
 * Description : LED specified for "ledno" is lighting. 
 * Argument    : void
 * Return Value: void
 * Note        : None
*******************************************************************************/
void led_on(unsigned short ledno)
{

	if(ledno & ID_LED2){
		PORT.PJDR1.BIT.PJ19DR = 0;
	}

	if(ledno & ID_LED1){
		PORT.PJDR1.BIT.PJ18DR = 0;
	}

}

/*******************************************************************************
 * ID          : 
 * Outline     : Turning off
 * Include     : #include "iodefine.h"
 * Declaration : void led_off(unsigned short ledno);
 * Description : LED specified for "ledno" is turned off. 
 * Argument    : int ledno : LED number
 * Return Value: void
 * Note        : None
*******************************************************************************/
void led_off(unsigned short ledno)
{

	if(ledno & ID_LED2){
		PORT.PJDR1.BIT.PJ19DR = 1;
	}

	if(ledno & ID_LED1){
		PORT.PJDR1.BIT.PJ18DR = 1;
	}

}
/* End of File */
