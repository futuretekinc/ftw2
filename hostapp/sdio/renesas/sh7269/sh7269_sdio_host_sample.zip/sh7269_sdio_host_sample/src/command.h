/******************************************************************************
*   DISCLAIMER
*
*   This software is supplied by Renesas Electronics Corp. and is only 
*   intended for use with Renesas products. No other uses are authorized.
*
*   This software is owned by Renesas Electronics Corp. and is protected under 
*   all applicable laws, including copyright laws.
*
*   THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
*   REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
*   INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
*   PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
*   DISCLAIMED.
*
*   TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
*   ELECTRONICS CORP. NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
*   FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
*   FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS
*   AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
*   Renesas reserves the right, without notice, to make changes to this 
*   software and to discontinue the availability of this software.
*   By using this software, you agree to the additional terms and 
*   conditions found by accessing the following link: 
*   http://www.renesas.com/disclaimer
********************************************************************************
*   Copyright (C) 2013 Renesas Electronics Corporation. All rights reserved.
**************************** Technical reference data **************************
*   System Name : SH7269 SDIO HOST Sample Program
*   File Name   : command.h
*   Abstract    : Command header file
*   Version     : 1.00.00
*   Device      : SH7268/SH7269
*   Tool-Chain  : High-performance Embedded Workshop (Ver.4.08.00).
*               : C/C++ compiler package for the SuperH RISC engine family
*               :                             (Ver.9.04 Release00).
*   OS          : None
*   H/W Platform: R0K57269(CPU board)
*   Description : 
********************************************************************************
*   History     : May.28,2013 Ver.1.00.00
*******************************************************************************/
#ifndef _COMMAND_H_
#define _COMMAND_H_

/* ==== macros ==== */
#include <stdio.h>
#define DEBUGPRINT printf

#define ARGC			8		/* ������8�܂�	*/
#define MAX_ARGLENGTH 	270 	/* ���������̍ő吔	*/

#define	ERR_OK			0

#define MODE_SDIO		0

typedef struct{
	char *cmd_str;
	int (*cmdexe)(int, char **);
	int (*helpexe)(void);
}ST_COMMAND;

/* �R�}���h�����p�֐� */

int cmd_sdio_mount(int argc, char **argv);
int cmd_sdio_unmount(int argc, char **argv);
int cmd_sdio_cmd52_r(int argc, char **argv);
int cmd_sdio_cmd52_w(int argc, char **argv);
int cmd_sdio_get_info(int argc, char **argv);
int cmd_sdio_cmd53_byt_r(int argc, char **argv);
int cmd_sdio_cmd53_byt_w(int argc, char **argv);
int cmd_sdio_cmd53_blk_r(int argc, char **argv);
int cmd_sdio_cmd53_blk_w(int argc, char **argv);
int cmd_sdio_set_bus_width(int argc, char **argv);
int cmd_sdio_set_block_size(int argc, char **argv);
int cmd_sdio_exit(int argc, char **argv);
int cmd_sdio_txtest(int argc, char **argv);
int cmd_sdio_rxtest(int argc, char **argv);


int help_sdio_mount(void);
int help_sdio_unmount(void);
int help_sdio_cmd52_r(void);
int help_sdio_cmd52_w(void);
int help_sdio_get_info(void);
int help_sdio_cmd53_byt_r(void);
int help_sdio_cmd53_byt_w(void);
int help_sdio_cmd53_blk_r(void);
int help_sdio_cmd53_blk_w(void);
int help_sdio_set_bus_width(void);
int help_sdio_set_block_size(void);
int help_sdio_exit(void);
int help_sdio_txtest(void);
int help_sdio_rxtest(void);


#endif /* _COMMAND_H_ */
/* End of File */